<?php
/**
 * Importer classes for providers that use an API to provide jobs.
 *
 * https://publisher.whatjobs.com/publisher/api/info
 *
 * @package GoFetch/Admin/Premium/Professional/API Providers
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * The class for the WhatJobs Feed API.
 */
class GoFetch_WhatJobs_API_Feed_Provider extends GoFetch_API_Feed_Provider {

	/**
	 * @var The single instance of the class.
	 */
	protected static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Setup the base data for the provider.
	 */
	public function __construct() {
		global $goft_wpjm_options;

		$this->id      = 'api.whatjobs.com';
		$this->api_url = sprintf( 'https://api.whatjobs.com/api/v1/jobs.xml?publisher=%1$s', esc_attr( $goft_wpjm_options->whatjobs_publisher_id ) );

		$this->init_hooks();
	}

	/**
	 * Initialize hooks.
	 */
	public function init_hooks() {
		add_action( 'tabs_go-fetch-jobs_page_go-fetch-jobs-wpjm-providers', array( $this, 'tabs' ), 105 );
		add_filter( 'goft_wpjm_providers', array( $this, 'providers' ), 15 );
		add_action( 'goft_wpjm_feed_builder_fields', array( $this, 'feed_builder_fields' ) );
		add_filter( 'goft_wpjm_import_item_params', array( $this, 'params_meta' ), 10, 2 );

		// Frontend.
		add_action( 'goft_no_robots', array( $this, 'maybe_no_robots' ), 10, 2 );
	}

	/**
	 * Init the WhatJobs tabs.
	 */
	public function tabs( $all_tabs ) {
		$this->all_tabs = $all_tabs;
		$this->all_tabs->tabs->add( 'whatjobs', __( 'WhatJobs', 'gofetch-wpjm' ) );
		$this->tab_careerjet();
	}

	/**
	 * WhatJobs settings tab.
	 */
	protected function tab_careerjet() {

		$info_url = 'https://publisher.whatjobs.com/publisher/register';

		$this->all_tabs->tab_sections['whatjobs']['logo'] = array(
			'title' => '',
			'fields' => array(
				array(
					'title'  => '',
					'name'   => '_blank',
					'type'   => 'custom',
					'render' => function() {
						echo '<img class="api-providers-logo" src="' . esc_url( $this->get_config('logo') ) . '">';
					},
				),
			),
		);

		$this->all_tabs->tab_sections['whatjobs']['settings'] = array(
			'title' => __( 'Account Details', 'gofetch-wpjm' ),
			'fields' => array(
				array(
					'title'   => __( 'Country', 'gofetch-wpjm' ),
					'name'    => 'whatjobs_feed_default_locale_code',
					'type'    => 'select',
					'choices' => $this->locales(),
					'tip'     => __( 'Select the country that corresponds to your Publisher ID. ', 'gofetch-wpjm' ),
				),
				array(
					'title' => __( 'Publisher ID *', 'gofetch-wpjm' ),
					'name'  => 'whatjobs_publisher_id',
					'type'  => 'text',
					'extra' => array(
						'style' => 'width: 100px',
						'class' => 'field_dependent',
					),
					'desc'  => sprintf( __( 'Sign up for a free <a href="%1$s" target="_new">WhatJobs Publisher Account</a>.', 'gofetch-wpjm' ), esc_url( $info_url ) ),
					'tip'   => __( 'You need a publisher ID in order to pull jobs from WhatJobs.', 'gofetch-wpjm' ),
				),
			),
		);

		$this->all_tabs->tab_sections['whatjobs']['defaults'] = array(
			'title' => __( 'Feed Defaults', 'gofetch-wpjm' ),
			'fields' => array(
				array(
					'title' => __( 'Limit', 'gofetch-wpjm' ),
					'name'  => 'whatjobs_feed_default_limit',
					'type'  => 'text',
					'extra' => array(
						'class' => 'small-text',
					),
					'tip' => __( 'Maximum number of jobs returned per query. Max recommended, is 100.', 'gofetch-wpjm' ),
				),
			),
		);

		$this->all_tabs->tab_sections['whatjobs']['jobs'] = array(
			'title' => __( 'Jobs', 'gofetch-wpjm' ),
			'fields' => array(
				array(
					'title' => __( 'Block Search Indexing', 'gofetch-wpjm' ),
					'name'  => 'whatjobs_block_search_indexing',
					'type'  => 'checkbox',
					'desc' => __( 'Yes', 'gofetch-wpjm' ),
					'tip' => __( 'Check this option to block search robots from indexing imported jobs pages from this provider API.', 'gofetch-wpjm' ) .
							'<br/><br/>' . __( 'This option should be checked for providers that do not allow indexing their jobs.', 'gofetch-wpjm' ),
				),
				array(
					'title'  => __( '<small>(*) Required field</small>', 'gofetch-wpjm' ),
					'name'   => '_blank',
					'type'   => 'custom',
					'render' => '__return_false',
				),
			),
		);

	}

	/**
	 * Enqueues WhatJobs in the list of providers.
	 */
	public function providers( $providers ) {
		global $goft_wpjm_options;

		$new_providers = array(
			'api.whatjobs.com' => array(
				'API' => array(
					'info'      => 'https://publisher.whatjobs.com/publisher/api/info',
					'callback' => array(
						'fetch_feed'       => array( $this, 'fetch_feed' ),
						'fetch_feed_items' => array( $this, 'fetch_feed_items' ),
					),
					'required_fields' => array(
						'Publisher ID' => 'whatjobs_publisher_id',
					),
				),
				'website'     => 'https://www.whatjobs.com/',
				'logo'        => GoFetch_Jobs()->plugin_url() . '/includes/images/logos/logo-whatjobs.svg',
				'description' => 'WhatJobs is an employment search engine.',
				'feed'        => array(
					'base_url'   => $this->get_api_url(),
					'search_url' => 'http://www.careerjet.com/search/advanced.html',
					// Feed URL query args. Key value pairs of valid keys => provider_key/default_key_value.
					'query_args'  => array(
						'keyword'  => array( 'keyword' => '' ),
						'location' => array( 'location' => '' ),
						'radius'   => array( 'sort'  => esc_attr( $goft_wpjm_options->whatjobs_feed_default_sort ) ),
						'limit'    => array( 'limit'  => esc_attr( $goft_wpjm_options->whatjobs_feed_default_limit ) ),
					),
					'pagination' => array(
						'params'  => array(
							'page'  => 'page',
							'limit' => 'limit',
						),
						'results' => 50,
					),
					'default' => false,
					'full_description' => true,
				),

				'multi_region_match' => 'whatjobs',
				'weight' => 9,
				'category' => 'API',
			),
		);
		return array_merge( $providers, $new_providers );
	}

	/**
	 * Outputs specific WhatJobs feed parameter fields.
	 */
	public function feed_builder_fields( $provider ) {

		if ( ! $this->condition( $provider ) ) {
			return;
		}
	}

	/**
	 * Fetch the API feed.
	 */
	public function fetch_feed( $url ) {
		$params = array(
			'user_ip'    => urlencode( BC_Framework_Utils::get_user_ip() ),
			'user_agent' => urlencode( sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ) ),
		);
		$url = add_query_arg( $params, $url );

		$api_data = $this->get_api_data( $url );

		if ( is_wp_error( $api_data ) ) {
			return $api_data;
		}

		if ( $error = $this->maybe_raise_error( $api_data, empty( $api_data['data'] ), $url ) ) {
			return $error;
		}
		return $api_data['data']['job'];
	}

	/**
	 * Fetch items from the API feed.
	 */
	public function fetch_feed_items( $items, $url, $provider ) {
		global $goft_wpjm_options;

		$new_items = $sample_item = array();

		$defaults = array(
			'title'    => '',
			'company'  => '',
			'location' => '',
			'snippet'  => '',
			'url'      => '',
			'job_type' => '',
			'salary'   => '',
			'postcode' => '',
			'logo'     => '',
			'age'      => '',
			'age_days' => '',
		);

		foreach ( (array) $items as $job ) {
			$job = wp_parse_args( $job, $defaults );

			$new_item = array();

			$new_item['provider_id'] = $provider['id'];
			$new_item['title']       = sanitize_text_field( $job['title'] );
			$new_item['date']        = GoFetch_Importer::get_valid_date( $job['age'], 'api' );
			$new_item['location']    = sanitize_text_field( $job['location'] );
			$new_item['company']     = sanitize_text_field( $job['company'] );
			$new_item['description'] = GoFetch_Importer::format_description( $job['snippet'] );
			$new_item['link']        = esc_url_raw( html_entity_decode( ( $job['url'] ) ) );
			$new_item['site']        = sanitize_text_field( $job['site'] );

			if ( ! empty( $job['logo'] ) ) {
				$new_item['logo'] = is_array( $job['logo'] ) ? esc_url( $job['logo'][0] ): esc_url( $job['logo'] );
			}

			if ( ! empty( $job['salary'] ) ) {
				$new_item['salary'] = is_array( $job['salary'] ) ? implode( '-', array_map( 'sanitize_text_field', $job['salary'] ) ): sanitize_text_field( $job['salary'] );
			}

			if ( ! empty( $job['postcode'] ) ) {
				$new_item['postcode'] = is_array( $job['postcode'] ) ? implode( ',', array_map( 'sanitize_text_field', $job['postcode'] ) ): sanitize_text_field( $job['postcode'] );
			}

			if ( ! empty( $job['job_type'] ) ) {
				$new_item['job_type'] = is_array( $job['job_type'] ) ? implode( ',', array_map( 'sanitize_text_field', $job['job_type'] ) ): sanitize_text_field( $job['job_type'] );
			}

			$new_item = apply_filters( 'goft_wpjm_fetch_feed_item', $new_item, $provider, $url, $job, $defaults );

			// Find the item with the most attributes to use as sample.
			if ( count( array_keys( $new_item ) ) > count( array_keys( $sample_item ) ) ) {
				$sample_item                = $new_item;
				$sample_item['description'] = GoFetch_Importer::shortened_description( $job['snippet'] );
			}

			$sample_item = apply_filters( 'goft_wpjm_fetch_feed_sample_item', $sample_item, $provider, $new_item );

			$new_items[] = $new_item;
		}

		// Clear memory.
		$items = null;

		// __LOG.
		// Maybe log import info.
		$vars = array(
			'context' => 'GOFT :: ITEMS COLLECTED FROM FEED',
			'items'   => count( $new_items ),
		);
		BC_Framework_Debug_Logger::log( $vars, $goft_wpjm_options->debug_log );
		// __END LOG.

		$provider['name'] = 'WhatJobs';

		return array(
			'provider'    => $provider,
			'items'       => $new_items,
			'sample_item' => $sample_item,
		);
	}

	/**
	 * Set specific meta from Careerjet.
	 */
	public function params_meta( $params, $item ) {
		global $goft_wpjm_options;

		if ( empty( $item['provider_id'] ) || ! $this->condition( $item['provider_id'] ) ) {
			return $params;
		}

		// Geolocation.
		if ( ! empty( $item['location'] ) ) {
			$params['meta'][ $goft_wpjm_options->setup_field_formatted_address ] = $item['location'];
		}
		return $params;
	}

	/**
	 * Block robots if option is enabled.
	 */
	public function maybe_no_robots( $robots, $feed ) {
		global $goft_wpjm_options;

		if ( ! $this->condition() ) {
			return $robots;
		}

		if ( $goft_wpjm_options->whatjobs_block_search_indexing ) {
			$robots['noindex'] = true;
		}
		return $robots;

	}

	/**
	 * Retrieve a list of all the available country codes.
	 */
	public function locales() {
		$locales = array (
			'100' => 'United States',
			'101' => 'Austria',
			'102' => 'Germany',
			'103' => 'Ireland',
			'104' => 'Spain',
			'105' => 'Portugal',
			'106' => 'Switzerland',
			'107' => 'Brasil',
			'108' => 'Argentina',
			'109' => 'Mexico',
			'112' => 'Russia',
			'114' => 'Australia',
			'115' => 'Canada',
			'116' => 'Chile',
			'117' => 'Colombia',
			'118' => 'Ghana',
			'119' => 'India',
			'120' => 'Indonesia',
			'121' => 'Kenya',
			'122' => 'Malaysia',
			'123' => 'New Zealand',
			'124' => 'Nigeria',
			'125' => 'Pakistan',
			'126' => 'Philippines',
			'127' => 'Singapore',
			'128' => 'SouthAfrica',
			'129' => 'Tanzania',
			'130' => 'Uganda',
			'131' => 'United Arab Emirates',
			'134' => 'United Kingdom',
			'135' => 'France',
			'143' => 'Venezuela',
			'144' => 'Peru',
			'145' => 'Bolivia',
			'146' => 'Ecuador',
			'147' => 'Uruguay',
			'148' => 'Puerto Rico',
			'149' => 'Costa Rica',
			'150' => 'Repuplica Dominica',
			'151' => 'Algeria',
			'152' => 'Morocco',
			'153' => 'Tunisia',
			'154' => 'Madagascar',
			'155' => 'Senegal',
			'156' => 'Belgium',
			'157' => 'Egypt',
			'158' => 'Guatemala',
			'160' => 'Netherlands',
			'161' => 'Italy',
			'163' => 'HongKong',
			'165' => 'Panama',
			'166' => 'Thailand',
			'167' => 'Vietnam',
			'168' => 'SriLanka',
			'169' => 'Saudi Arabia',
			'170' => 'Bahrain',
			'171' => 'Oman',
			'172' => 'Qatar',
			'173' => 'Saudi Arabia (En)',
			'174' => 'Qatar (En)',
			'175' => 'Oman (En)',
			'176' => 'Bangladesh',
			'177' => 'Paraguay',
			'178' => 'Luxembourg',
			'179' => 'Kuwait',
			'183' => 'Poland',
			'184' => 'Sweden',
		);
		asort( $locales );
		return $locales;
	}

}
new GoFetch_WhatJobs_API_Feed_Provider();


/**
 composer require erusev/parsedown

require 'vendor/autoload.php';
use Parsedown;

function textAndMarkdownToHtml($text) {
    // Convert new lines to line breaks
    $text = nl2br($text);

    // Split the text into paragraphs
    $paragraphs = explode("\n\n", $text);

    // Convert each paragraph and list into HTML
    $html = '';
    $parsedown = new Parsedown();
    foreach ($paragraphs as $paragraph) {
        // Check if the paragraph starts with a '-' to detect a list item
        if (strpos($paragraph, '-') === 0) {
            // If it starts with a '-', treat it as a list
            $listItems = explode("\n", $paragraph);
            $html .= '<ul>';
            foreach ($listItems as $item) {
                // Remove the leading '-' and trim any whitespace
                $item = trim(substr($item, 1));
                $html .= '<li>' . $parsedown->line($item) . '</li>';
            }
            $html .= '</ul>';
        } else {
            // If it's not a list, parse the Markdown syntax
            $html .= $parsedown->text($paragraph);
        }
    }

    return $html;
}

*/
