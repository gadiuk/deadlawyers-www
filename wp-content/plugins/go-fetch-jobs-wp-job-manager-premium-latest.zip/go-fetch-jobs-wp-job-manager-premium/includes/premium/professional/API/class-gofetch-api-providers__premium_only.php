<?php
/**
 * Importer classes for providers that use an API to provide jobs.
 *
 * @package GoFetch/Admin/Premium/Pro+/API Providers
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * The abtract class for any feed based on an API.
 */
abstract class GoFetch_API_Feed_Provider {

	/**
	 * The provider unique string ID.
	 *
	 * @string $id
	 */
	protected $id;

	/**
	 * The API URL.
	 *
	 * @string $api_url
	 */
	protected $api_url;

	/**
	 * Wether the API requires tracking update for the job links
	 *
	 * @string $tracking_update
	 */
	protected $tracking_update;

	/**
	 * Returns base config for the provider.
	 */
	public function config( $providers = array() ) {
		return apply_filters( 'goft_wpjm_providers', $providers );
	}

	/**
	 * Get the provider config.
	 */
	protected function get_config( $key = '' ) {
		$config = $this->config();

		$data = $config[ $this->id ];

		if ( ! $key ) {
			return $data;
		} else if ( ! empty( $data[ $key ] ) ) {
			return $data[ $key ];
		}
		return array();
	}

	/**
	 * The method that connects and pulls the data from the API feed.
	 */
	protected function get_api_data( $url, $xml_data = false, $api_args = array() ) {

		$api_args = apply_filters( 'goft_wpjm_fetch_feed_api_args', wp_parse_args( $api_args, array( 'timeout' => 10 ) ), $this->id );

		$result = wp_remote_get( esc_url_raw( $url ), $api_args );

		if ( ! is_wp_error( $result ) ) {

			$response_headers = wp_remote_retrieve_headers( $result );

			// Double check if we're getting XML content.
			if ( ! empty( $response_headers['content-type'] ) && strpos( $response_headers['content-type'], 'text/xml' ) >= 0 ) {
				$xml_data = true;
			}

			if ( $xml_data ) {

				$json = wp_remote_retrieve_body( $result );

				if ( ! GoFetch_Helper::is_json( $json ) ) {
					if ( $simple_xml = simplexml_load_string( $json, null, LIBXML_NOCDATA ) ) {
						$json = wp_json_encode( $simple_xml );
					}
				}
			} else {
				$json = wp_remote_retrieve_body( $result );
			}

			$result = json_decode( $json, true );

			if ( ( isset( $result['message'] ) && empty( $result['data'] ) ) || isset( $result['error'] ) || isset( $result['errors'] ) || isset( $result['publisher'][0] ) ) {
				global $goft_wpjm_options;

				$error = ! empty( $result['error'] ) ? $result['error'] : ( ! empty( $result['message'] ) ? $result['message'] : ( isset( $result['errors'] ) ? $result['errors'] :  $result['publisher'][0] ) );

				if ( is_array( $error ) ) {
					$error = implode( ', ', $error );
				}

				$setting_errors = '';

				$provider = GoFetch_RSS_Providers::get_providers( $this->id );

				foreach ( $provider['API']['required_fields'] as $field => $option ) {
					if ( ! $goft_wpjm_options->$option ) {
						$setting_errors .= html( 'span', sprintf( '- %s is empty!<br/>', $field ) );
					}
				}

				if ( $setting_errors ) {
					$setting_errors .= html( 'span', sprintf( __( 'Please fill in the required field(s) in the <a href="%s" style="color: #fff !important;">options page</a>.', 'gofetch-wpjm' ), esc_url( admin_url( 'admin.php?page=go-fetch-jobs-wpjm-settings' ) ) ) );
				}

				if ( ! empty( $setting_errors ) ) {
					$setting_errors = html( 'p class="goft_wpjm no-jobs-found feed"', $setting_errors );
				}

				return new WP_Error( 'api_feed_error', $error . $setting_errors );

			} elseif ( ! empty( $result ) ) {
				return $result;
			}
			return array();
		}
		return new WP_Error( 'api_feed_error', __( 'Could not read API feed. Please wait a few seconds and try again.', 'gofetch-wpjm' ) );
	}

	/**
	 * The method that pulls the jobs from the API feed.
	 */
	abstract public function fetch_feed_items( $items, $url, $provider );

	/**
	 * The condition to be met to be able to execute methods on the class.
	 */
	protected function condition( $provider = '' ) {
		global $post;

		if ( ! $provider ) {
			$metadata = get_post_meta( $post->ID, '_goft_source_data', true );

			if ( empty( $metadata['feed_url'] ) ) {
				return false;
			}
			$provider = $metadata['feed_url'];
		}

		$provider_id = str_replace( array( 'api.', '/api' ), '', $this->id );

		return ( false !== strpos( $provider, $provider_id ) );
	}

	/**
	 * The method for retrieving the API URL.
	 */
	protected function get_api_url() {
		return $this->api_url;
	}

	/**
	 * Register the valid REST routes.
	 */
	public function register_rest_routes( $routes ) {
		$args = array(
			'methods'  => 'GET',
			'callback' => array( $this, 'get_api_jobs' ),
			'permission_callback' => function ( $request ) {

				// The token that provides access to the endpoint.
				$valid_token = md5( 'goft-wpjm-api-jobs' );

				$headers = $request->get_headers();

				if ( empty( $headers['x_goft_wpjm_rapi_token'] ) ) {
					return;
				}
				$token = array_pop( $headers['x_goft_wpjm_rapi_token'] );

				return ( $token === $valid_token );
			},
		);
		register_rest_route( 'goft/v1', '/api_jobs', $args );
	}

	/**
	 * Some providers will expire their jobs so we need to fetch the jobs again in real time to update the tracking ID.
	 */
	public function update_job_tracking() {
		global $post;
?>
		<script type="text/javascript">
			jQuery(function($) {

				var data = {
					post_id: '<?php echo (int) $post->ID; ?>'
				}, headers = {
					'X-goft-WPJM-RAPI-Token': '<?php echo md5( 'goft-wpjm-api-jobs' ); ?>'
				};

				$.ajax({
					type:    'GET',
					url:     '<?php echo esc_url_raw( get_rest_url( null, 'goft/v1/api_jobs' ) ); ?>',
					data:    data,
					headers: headers,
					success: function(res) {
						if ( ! res || typeof res['data'] === 'undefined' ) {
							return;
						}
						var job = res['data'];
						$('.goftj-logo-exernal-link').attr( 'href', job['link'] );
						$('.job_application .goftj-logo-exernal-link').html( job['link'] );

						if ( typeof job['link_atts']['javascript'] !== 'undefined' ) {
							$.each( job['link_atts']['javascript'].each, function(i, v) {
								$('.goftj-logo-exernal-link').attr( i, job['link_atts']['javascript'] );
							});
						}
					},
					error: function(res){
						//
					}
				}, 'json');
			});

		</script>
<?php
	}

	/**
	 * Fetch the jobs from the original feed to get updated links for the current job.
	 */
	public function get_api_jobs() {
		global $goft_wpjm_options;

		$post_id = (int) sanitize_text_field( $_REQUEST['post_id'] );

		$interval = (int) $this->tracking_update * 60;

		if ( $last_checked = get_post_meta( $post_id, '_goft_api_last_checked', true ) ) {
			$diff = round( ( current_time( 'timestamp' ) - $last_checked ) / 3600 );
		}

		// Skip if update interval is not set or yet met.
		if ( ! $this->tracking_update || ( ! empty( $diff ) && $diff <= $interval ) ) {
			return;
		}

		$jobkey  = get_post_meta( $post_id, '_goft_unique_jobkey', true );
		$jobfeed = get_post_meta( $post_id, '_goft_jobfeed', true );
		$item    = get_post_meta( $post_id, '_goft_wpjm_original_item', true );

		if ( ! $jobfeed || ! $item ) {
			return;
		}

		$jobs = $this->fetch_feed( $jobfeed );

		if ( empty( $jobs ) || is_wp_error( $jobs ) ) {
			return;
		}

		$provider['id'] = $item['provider_id'];
		$result = $this->fetch_feed_items( $jobs, $jobfeed, $provider );

		if ( $filtered_item = wp_list_filter( $result['items'], array( 'jobkey' => $jobkey ) ) ) {
			update_post_meta( $post_id, '_goft_api_last_checked', current_time( 'timestamp' ) );

			$matched_item = array_pop( $filtered_item );

			// Update the link with the new data.
			if ( ! empty( $matched_item['link'] ) ) {
				$matched_item['link'] = apply_filters( 'goft_wpjm_api_updated_job_link', $matched_item['link'], $post_id, $provider['id'] );
			}

			wp_send_json_success( $matched_item );
		} else {
			// Expire the post if option is selected.
			if ( $goft_wpjm_options->adview_expire_jobs ) {
				$post_arr = array(
					'ID'          => $post_id,
					'post_status' => $goft_wpjm_options->setup_expired_status,
				);
				wp_update_post( $post_arr );
			}
		}
		wp_send_json_error();
	}

	protected function has_paginated_results( $url, $query_params = array() ) {
		$config = $this->get_config('feed');

		if ( empty( $query_params ) ) {
			$parts = parse_url( $url );

			if ( ! empty( $parts['query'] ) ) {
				parse_str( $parts['query'], $query_params );
			}
		}
		return ( ! empty( $config['pagination'] ) && in_array( $config['pagination']['params']['page'], array_keys( $query_params ) ) );
	}

	/**
	 * Throws an error if there are missing parameters in the feed URL.
	 */
	private function maybe_raise_error_missing_params( $query_params ) {
		$config     = $this->get_config('feed');
		$config_api = $this->get_config('API');

		$required_params = $flipped_required_params = $required_params_labels = array();

		if ( isset( $config['required_query_params'] ) ) {
			$required_params = array_values( $config['required_query_params'] );
			$required_params_labels = array_flip( $config['required_query_params'] );
		}

		$required_params_api = array();

		if ( isset( $config_api['required_query_params'] ) ) {
			$required_params_api = array_values( $config_api['required_query_params'] );
			$required_params = array_merge( $required_params, $required_params_api );

			$required_params_labels = array_merge( $required_params_labels, array_flip( $config_api['required_query_params'] ) );
		}

		if ( empty( $required_params ) ) {
			return false;
		}

		$relation = in_array( 'relation_or', $required_params ) ? 'or' : 'and';

		foreach ( $required_params as $key => $value ) {
			if ( 'relation_or' !== $value ) {
				$flipped_required_params[ $value ] = '';
			}
		}

		// Parse the args to get any user set values
		$full_query_params = wp_parse_args( $query_params, $flipped_required_params );

		// Intersect the two arrays to get only the required params
		$full_query_params = array_intersect_key( $full_query_params, $flipped_required_params );

		$missing_fields = array_filter( $full_query_params, function( $value ) {
			return empty( $value );
		} );

		// Prioritize warning about the required params from the API.
		if ( array_intersect( array_keys( $missing_fields ), array_values( $required_params_api ) ) ) {
			$relation = '';
			$missing_fields = array_intersect_key( $missing_fields, array_flip( $required_params_api ) );
		} else {
			// If the relation is OR, we can skip the check, if at least one of the required params is present.
			if ( 'or' === $relation && count( $missing_fields ) < count( $full_query_params ) - 1 ) {
				$missing_fields = array();
			}
		}

		if ( ! empty( $missing_fields ) ) {

			$labeled_missing_fields = array();

			foreach ( $missing_fields as $key => $value ) {
				$label = $key;
				if ( isset( $required_params_labels[ $key ] ) ) {
					$label = sprintf( '<strong>%s</strong> (%s)', $key, ucfirst( $required_params_labels[ $key ] ) );
				}
				$labeled_missing_fields[] = $label ;
			}

			$message_note = __( 'Please fill in <strong>ALL</strong> the missing URL parameters, and try again', 'gofetch-wpjm' );

			if ( 'or' === $relation ) {
				$message_note = __( 'Please fill in <strong>AT LEAST ONE</strong> of the required URL parameters, and try again', 'gofetch-wpjm' );
			}

			$message = sprintf( __( 'The feed URL has missing or empty required parameters: <br/>%s', 'gofetch-wpjm' ), '<br/> - ' . implode( '<br/>- ', $labeled_missing_fields ) );
			$message .= '<br/><br/>' . $message_note;
			return $message;
		}
		return false;
	}

	/**
	 * Raise errors related with the API response.
	 */
	protected function maybe_raise_error( $api_data, $empty_jobs_key, $url ) {
		$parts = parse_url( $url );

		if ( ! empty( $parts['query'] ) ) {
			parse_str( $parts['query'], $query_params );
		}

		if ( ( ! $this->has_paginated_results( $url, $query_params ) && ( is_wp_error( $api_data ) ) || $empty_jobs_key ) ) {
			if ( $error = $this->maybe_raise_error_missing_params( $query_params ) ) {
				return new WP_Error( 'missing_query_params', $error );
			}

			if ( ! is_wp_error( $api_data ) ) {
				return new WP_Error( 'no_jobs_found', __( 'No jobs found. Try tweaking your search parameters.', 'gofetch-wpjm' ) );
			}
		}
		return false;
	}

}
