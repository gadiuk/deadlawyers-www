<?php
/**
 * Importer classes for providers that use an API to provide jobs.
 *
 * Docs: https://sourcestack.co/docs/quickstart/
 *
 * @package GoFetch/Admin/Premium/Professional/API Providers
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * The class for the sourcestack Feed API.
 */
class GoFetch_sourcestack_API_Feed_Provider extends GoFetch_API_Feed_Provider {

	/**
	 * @var The single instance of the class.
	 */
	protected static $_instance = null;

	/**
	 * The application URL.
	 */
	protected static $application_link = 'https://sourcestack.co/contact/?message=Hey%20Team%20SourceStack%20-%20I%27m%20a%20user%20of%20the%20GoFetchJobs%20Wordpress%20Plugin%20and%20I%27d%20like%20to%20a%20claim%20the%201%2C000%20job%20free%20trial.%20Can%20you%20set%20up%20an%20account%20for%20me%20with%20this%20email%20address%3F%20Thanks%21&via=GFJ';

	protected static $default_fields = array(
		'job_name'       => '',
		'post_html'      => '',
		'hours'          => '',
		'department'     => '',
		'seniority'      => '',
		'remote'         => '',
		'company_name'   => '',
		'company_url'    => '',
		'post_url'       => '',
		'tags_matched'   => array(),
		'tag_categories' => array(),
		'job_location'   => '',
		'city'           => '',
		'region'         => '',
		'postal_code'    => '',
		'country'        => '',
		'last_indexed'   => '',
		'logo_url'       => '',
	);

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Setup the base data for the provider.
	 */
	public function __construct() {
		$this->id      = 'api.sourcestack.com';
		$this->api_url = 'https://sourcestack-api.com/jobs/';

		$this->init_hooks();
	}

	/**
	 * Initialize hooks.
	 */
	public function init_hooks() {
		add_action( 'tabs_go-fetch-jobs_page_go-fetch-jobs-wpjm-providers', array( $this, 'tabs' ), 15 );
		add_filter( 'goft_wpjm_providers', array( $this, 'providers' ), 15 );
		add_action( 'goft_wpjm_feed_builder_fields', array( $this, 'feed_builder_fields' ) );

		// Frontend.
		add_filter( 'goft_no_robots', array( $this, 'maybe_no_robots' ), 10, 2 );
	}

	/**
	 * Init the SourceStack tabs.
	 */
	public function tabs( $all_tabs ) {
		$this->all_tabs = $all_tabs;
		$this->all_tabs->tabs->add( 'sourcestack', sprintf( '<span class="gofj-top-partner-tab"><span class="dashicons dashicons-star-empty"></span> %s</span>', __( 'SourceStack', 'gofetch-wpjm' ) ) );
		$this->tab_sourcestack();
	}

	/**
	 * SourceStack settings tab.
	 */
	protected function tab_sourcestack() {
		global $goft_wpjm_options;

		$docs = 'https://sourcestack.co/docs/quickstart/';

		$current_user = wp_get_current_user();

		$application_link = add_query_arg( array(
			'name'  => $current_user->user_firstname ? $current_user->user_firstname : $current_user->display_name,
			'email' => $current_user->user_email,
		), self::$application_link);

		$partner_announcement = ! $goft_wpjm_options->sourcestack_api_key ? '<div class="secondary-container provider-credits-info"><span class="dashicons-before dashicons-megaphone" style="padding-right: 8px"></span><div>' . sprintf( __( '<em>%1$s</em> customers are entitled to a <strong>1,000 jobs</strong> free trial. You can request your API key <a href="%2$s" target="_new">here</a>.', 'gofetch-wpjm' ), 'Go Fetch Jobs', esc_url( urldecode_deep( $application_link ) ) ) . '</div></div><br/>' : '';

		$this->all_tabs->tab_sections['sourcestack']['logo'] = array(
			'title' => '',
			'fields' => array(
				array(
					'title'  => '',
					'name'   => '_blank',
					'type'   => 'custom',
					'render' => function() use ( $partner_announcement ) {
						echo '<h2 class="gofj-top-partner"> <span class="dashicons dashicons-star-empty"></span> Top Partner <span class="dashicons-before dashicons-editor-help tip-icon bc-tip" title="Click to read additional info..." data-tooltip="A \'Top Partner\' means better integration and support."></span></h2>';
						echo wp_kses_post( $partner_announcement );
						echo '<img class="api-providers-logo" src="' . esc_url( $this->get_config('logo') ) . '">';
					},
				),
			),
		);

		$this->all_tabs->tab_sections['sourcestack']['settings'] = array(
			'title' => __( 'Account Details', 'gofetch-wpjm' ),
			'fields' => array(
				array(
					'title'   => __( 'Country', 'gofetch-wpjm' ),
					'name'    => 'sourcestack_feed_default_country',
					'type'    => 'select',
					'choices' => $this->locales(),
					'tip'     => __( 'Search within country specified.', 'gofetch-wpjm' ),
				),
				array(
					'title' => __( 'API Key', 'gofetch-wpjm' ),
					'name'  => 'sourcestack_api_key',
					'type'  => 'text',
					'desc'  => '<br/><br/>' . sprintf( __( 'Please visit <a href="%s" target="_new">SourceStack\'s website</a> to get more info, and purchase an API key.', 'gofetch-wpjm' ), self::$application_link )
							 . ( ! $goft_wpjm_options->sourcestack_api_key ? '<br/><br/>' . sprintf( __( 'Claim your <strong>1.000 jobs</strong> free trial API key <a href="%s" target="_new">here</a>.', 'gofetch-wpjm' ), self::$application_link ) : '' ),
					'tip'   => __( 'You need an application key in order to pull jobs from this provider.', 'gofetch-wpjm' ),
				),
			),
		);

		$this->all_tabs->tab_sections['sourcestack']['defaults'] = array(
			'title' => __( 'Feed Defaults', 'gofetch-wpjm' ),
			'fields' => array(
				array(
					'title' => __( 'City', 'gofetch-wpjm' ),
					'name'  => 'sourcestack_feed_default_city',
					'type'  => 'text',
					'tip' => __( 'Limit the results to a specific city. (i.e: Sydney).', 'gofetch-wpjm' ),
				),
				array(
					'title' => __( 'Region(s)', 'gofetch-wpjm' ),
					'name'  => 'sourcestack_feed_default_region',
					'type'  => 'text',
					'tip' => __( 'Limit results to a specific region (i.e: New South Wales).', 'gofetch-wpjm' ),
				),
				array(
					'title' => __( 'Remote', 'gofetch-wpjm' ),
					'name'  => 'sourcestack_feed_default_remote',
					'type'  => 'select',
					'choices' => array(
						''      => __( 'Include Remote', 'gofetch-wpjm' ),
						'false' => __( 'Exclude Remote', 'gofetch-wpjm' ),
						'true'  => __( 'Remote Only', 'gofetch-wpjm' ),
					),
					'tip' => __( 'Include, exclude or limit results, to Remote jobs.', 'gofetch-wpjm' ),
					'default' => '',
				),
				array(
					'title' => __( 'Company Name(s)', 'gofetch-wpjm' ),
					'name'  => 'sourcestack_feed_default_company',
					'type'  => 'text',
					'tip' => __( 'Comma separated list of company names (i.e: Canva, Amazon, etc).', 'gofetch-wpjm' ),
				),
				array(
					'title' => __( 'Job Types', 'gofetch-wpjm' ),
					'name'  => 'sourcestack_feed_default_job_type',
					'type'  => 'checkbox',
					'extra' => array(
						'style'            => 'width: 100%;',
						'multiple'         => 'multiple',
						'class'            => 'select2-gofj-multiple',
						'data-allow-clear' => 'true',
					),
					'choices' => self::job_types(),
					'tip' => __( 'Choose the job type(s) that best suit your job board.', 'gofetch-wpjm' ),
				),
				array(
					'title' => __( 'Job Categories', 'gofetch-wpjm' ),
					'name'  => 'sourcestack_feed_default_job_category',
					'type'  => 'checkbox',
					'extra' => array(
						'style'            => 'width: 100%;',
						'multiple'         => 'multiple',
						'class'            => 'select2-gofj-multiple',
						'data-allow-clear' => 'true',
					),
					'choices' => self::categories(),
					'tip' => __( 'Choose the job categories that best suit your job board.', 'gofetch-wpjm' ),
				),
				array(
					'title' => __( 'Job Education', 'gofetch-wpjm' ),
					'name'  => 'sourcestack_feed_default_job_education',
					'type'  => 'checkbox',
					'extra' => array(
						'style'            => 'width: 100%;',
						'multiple'         => 'multiple',
						'class'            => 'select2-gofj-multiple',
						'data-allow-clear' => 'true',
					),
					'choices' => self::job_education(),
					'tip' => __( 'Choose the eduction levels that best suit your job board.', 'gofetch-wpjm' ),
				),
				array(
					'title' => __( 'Results Per Page', 'gofetch-wpjm' ),
					'name'  => 'sourcestack_feed_default_limit',
					'type'  => 'text',
					'extra' => array(
						'class' => 'small-text',
					),
					'tip' => __( 'The number of jobs to include on the results. Max recommended is \'100\'.', 'gofetch-wpjm' ) .
					'<br/><br/>' . __( 'Please make sure you take in consideration your credits limit (1 credit = 1 job).', 'gofetch-wpjm' )
				),
			),
		);

		$this->all_tabs->tab_sections['sourcestack']['jobs'] = array(
			'title' => __( 'Jobs', 'gofetch-wpjm' ),
			'fields' => array(
				array(
					'title' => __( 'Block Search Indexing', 'gofetch-wpjm' ),
					'name'  => 'adzuna_block_search_indexing',
					'type'  => 'checkbox',
					'desc' => __( 'Yes', 'gofetch-wpjm' ),
					'tip' => __( 'Check this option to block search robots from indexing imported jobs pages from this provider API.', 'gofetch-wpjm' ) .
						'<br/><br/>' . __( 'This option should be checked for providers that do not allow indexing their jobs.', 'gofetch-wpjm' ),
				),
				array(
					'title'  => __( '<small>(*) Required field</small>', 'gofetch-wpjm' ),
					'name'   => '_blank',
					'type'   => 'custom',
					'render' => '__return_false',
				),
			),
		);

	}

	/**
	 * Enqueues sourcestack in the list of providers.
	 */
	public function providers( $providers ) {
		global $goft_wpjm_options;

		$new_providers = array(
			'api.sourcestack.com' => array(
				'API' => array(
					'info'      => 'https://sourcestack.co',
					'callback' => array(
						'fetch_feed'       => array( $this, 'fetch_feed' ),
						'fetch_feed_items' => array( $this, 'fetch_feed_items' ),
					),
					'required_fields' => array(
						'API Key'  => 'sourcestack_api_key',
					),
					'required_query_params' => array(
						'Name'  => 'name',
					),
				),
				'website'     => 'https://sourcestack.co/',
				'logo'        => GoFetch_Jobs()->plugin_url() . '/includes/images/logos/logo-sourcestack.png',
				'description' => 'B2B Data Service - SourceStack',
				'feed'        => array(
					'base_url'   => $this->get_api_url(),
					'search_url' => 'https://sourcestack-api.com/jobs',
					// Feed URL query args. Key value pairs of valid keys => provider_key/default_key_value.
					'query_args'  => array(
						'keyword'  => array( 'job_name' => '' ),
						'limit'    => array( 'limit'  => esc_attr( $goft_wpjm_options->sourcestack_feed_default_limit ) ),
						'country'  => array( 'country' => esc_attr( $goft_wpjm_options->sourcestack_feed_default_country ) ),
						'company'  => array( 'company_name' => esc_attr( $goft_wpjm_options->sourcestack_feed_default_company ) ),

						// Custom
						'fields'      => array( 'fields' => '' ),
						'categories'  => array( 'categories' => esc_attr( implode( ',', (array) $goft_wpjm_options->sourcestack_feed_default_job_category ) ) ),
						'language'    => array( 'language' => esc_attr( $goft_wpjm_options->sourcestack_feed_default_language ) ),
						'city'        => array( 'city' => esc_attr( $goft_wpjm_options->sourcestack_feed_default_city ) ),
						'region'      => array( 'region' => esc_attr( $goft_wpjm_options->sourcestack_feed_default_region ) ),
						'postal_code' => array( 'postal_code' => '' ),
						'remote'      => array( 'remote' => esc_attr( $goft_wpjm_options->sourcestack_feed_default_remote ) ),
						'hours'       => array( 'hours'   => esc_attr( implode( ',', (array) $goft_wpjm_options->sourcestack_feed_default_job_type ) ) ),
						'education'   => array( 'education' => esc_attr( implode( ',', (array) $goft_wpjm_options->sourcestack_feed_default_job_education ) ) ),
						'job_published_at_operator' => array( 'job_published_at_operator' => '' ),
						'job_published_at' => array( 'job_published_at' => '' ),
					),
					'full_description' => true,
					'default' => false,
				),
				'multi_region_match' => 'sourcestack',
				'region_param_domain' => 'country',
				'region_domains' => $this->locales(),
				'region_default' => $goft_wpjm_options->sourcestack_feed_default_country,
				'partner' => true,
				'partner_msg' => sprintf( __( '<em>SourceStack</em> is a Partner provider. If you are not a publisher yet, you can <a href="%s" target="_blank">apply here</a>.' ), self::$application_link ),
				'category' => array( ' ' . __( 'Partners', 'gofetch-wpjm' ), 'API' ),
				'weight'   => 10,
			),
		);
		return array_merge( $providers, $new_providers );
	}

	/**
	 * Outputs specific sourcestack feed parameter fields.
	 */
	public function feed_builder_fields( $provider ) {

		if ( ! $this->condition( $provider ) ) {
			return;
		}

		$field_categories = array(
			'title'   => __( 'Job Categories', 'gofetch-wpjm' ),
			'name'    => 'feed-categories',
			'type'    => 'select',
			'choices' => self::categories(),
			'class'   => 'regular-text',
			'extra'   => array(
				'data-qarg' => 'feed-param-categories',
				'multiple'  => 'multiple',
				'style'     => "width: 700px;",
			),
			'default' => '',
		);

		$field_job_types = array(
			'title'   => __( 'Job Type', 'gofetch-wpjm' ),
			'name'    => 'feed-hours',
			'type'    => 'select',
			'choices' => self::job_types(),
			'class'   => 'regular-text',
			'extra'   => array(
				'data-qarg' => 'feed-param-hours',
				'multiple'  => 'multiple',
				'style'     => "width: 350px;",
			),
			'default' => '',
		);

		$field_job_education = array(
			'title'   => __( 'Job Education', 'gofetch-wpjm' ),
			'name'    => 'feed-education',
			'type'    => 'select',
			'choices' => self::job_education(),
			'class'   => 'regular-text',
			'extra'   => array(
				'data-qarg' => 'feed-param-education',
				'multiple'  => 'multiple',
				'style'     => "width: 350px;",
			),
			'default' => '',
		);
?>

		<?php $field_name = 'city'; ?>
		<p class="params opt-param-<?php echo esc_attr( $field_name ); ?>">
			<label for="feed-latlong"><strong><?php _e( 'City', 'gofetch-wpjm' ); ?></strong>
				<span class="tip"><span class="dashicons-before dashicons-editor-help tip-icon bc-tip" data-tooltip="<?php echo esc_attr( __( 'Limit the results to a specific city.', 'gofetch-wpjm' ) ); ?>"></span></span>
			</label><span class="feed-param-<?php echo esc_attr( $field_name ); ?>"></span>
			<input type="text" class="regular-text" style="width: 250px" style name="feed-<?php echo esc_attr( $field_name ); ?>" data-qarg="feed-param-<?php echo esc_attr( $field_name ); ?>" placeholder="<?php echo __( 'i.e.: Sydney', 'gofetch-wpjm' ); ?>">
			<input type="hidden" name="feed-param-<?php echo esc_attr( $field_name ); ?>">
		</p>

		<?php $field_name = 'region'; ?>
		<p class="params opt-param-<?php echo esc_attr( $field_name ); ?>">
			<label for="feed-latlong"><strong><?php _e( 'Region(s)', 'gofetch-wpjm' ); ?></strong>
				<span class="tip"><span class="dashicons-before dashicons-editor-help tip-icon bc-tip" data-tooltip="<?php echo esc_attr( __( 'Limit the results to a specific region.', 'gofetch-wpjm' ) ); ?>"></span></span>
			</label><span class="feed-param-<?php echo esc_attr( $field_name ); ?>"></span>
			<input type="text" class="regular-text" style="width: 250px" style name="feed-<?php echo esc_attr( $field_name ); ?>" data-qarg="feed-param-<?php echo esc_attr( $field_name ); ?>" placeholder="<?php echo __( 'i.e.: New South Wales', 'gofetch-wpjm' ); ?>">
			<input type="hidden" name="feed-param-<?php echo esc_attr( $field_name ); ?>">
		</p>

		<?php $field_name = 'postal_code'; ?>
		<p class="params opt-param-<?php echo esc_attr( $field_name ); ?>">
			<label for="feed-latlong"><strong><?php _e( 'Postal Code', 'gofetch-wpjm' ); ?></strong>
				<span class="tip"><span class="dashicons-before dashicons-editor-help tip-icon bc-tip" data-tooltip="<?php echo esc_attr( __( 'i.e.: 2000', 'gofetch-wpjm' ) ); ?>"></span></span>
			</label><span class="feed-param-<?php echo esc_attr( $field_name ); ?>"></span>
			<input type="text" class="regular-text" style="width: 100px" style name="feed-<?php echo esc_attr( $field_name ); ?>" data-qarg="feed-param-<?php echo esc_attr( $field_name ); ?>" placeholder="<?php echo __( 'i.e.: 2000', 'gofetch-wpjm' ); ?>">
			<input type="hidden" name="feed-param-<?php echo esc_attr( $field_name ); ?>">
		</p>

		<div class="clear"></div>

		<?php $field_name = 'company'; ?>
		<p class="params opt-param-<?php echo esc_attr( $field_name ); ?>">
			<label for="feed-latlong"><strong><?php _e( 'Company Name(s)', 'gofetch-wpjm' ); ?></strong>
				<span class="tip"><span class="dashicons-before dashicons-editor-help tip-icon bc-tip" data-tooltip="<?php echo esc_attr( __( 'Limit results to specific company name(s). Separate multiple company names using a comma.', 'gofetch-wpjm' ) ); ?>"></span></span>
			</label><span class="feed-param-<?php echo esc_attr( $field_name ); ?>"></span>
			<input type="text" class="regular-text" style="width: 250px" style name="feed-<?php echo esc_attr( $field_name ); ?>" data-qarg="feed-param-<?php echo esc_attr( $field_name ); ?>" placeholder="<?php echo __( 'i.e.: Canva, Amazon', 'gofetch-wpjm' ); ?>">
			<input type="hidden" name="feed-param-<?php echo esc_attr( $field_name ); ?>">
		</p>

		<?php $field_name = 'remote'; ?>
		<p class="params opt-param-<?php echo esc_attr( $field_name ); ?>">
			<label for="feed-<?php echo esc_attr( $field_name ); ?>"><strong><?php _e( 'Remote', 'gofetch-wpjm' ); ?></strong>
				<span class="tip"><span class="dashicons-before dashicons-editor-help tip-icon bc-tip" data-tooltip="<?php echo esc_attr( __( 'Include, exclude or limit results, to Remote jobs. Please note that this option will only work correctly for jobs that were tagged as \'Remote\', by the company.', 'gofetch-wpjm' ) ); ?>"></span></span>
			</label><span class="feed-param-<?php echo esc_attr( $field_name ); ?>"></span>
			<select class="regular-text" style="width: auto;" name="feed-<?php echo esc_attr( $field_name ); ?>" data-qarg="feed-param-<?php echo esc_attr( $field_name ); ?>">
				<option value="">Include Remote</option>
				<option value="false">Exclude Remote</option>
				<option value="true">Remote Only</option>
			</select>
			<input type="hidden" name="feed-param-<?php echo esc_attr( $field_name ); ?>">
		</p>

		<?php $field_name = 'job_published_at_operator'; ?>
		<p class="params opt-param-<?php echo esc_attr( $field_name ); ?>">
			<label for="feed-<?php echo esc_attr( $field_name ); ?>"><strong><?php _e( 'Published Date', 'gofetch-wpjm' ); ?></strong>
				<span class="tip"><span class="dashicons-before dashicons-editor-help tip-icon bc-tip" data-tooltip="<?php echo esc_attr( __( 'Limit results by published date.', 'gofetch-wpjm' ) ); ?>"></span></span>
			</label><span class="feed-param-<?php echo esc_attr( $field_name ); ?>"></span>
			<select class="regular-text" style="width: auto;" name="feed-<?php echo esc_attr( $field_name ); ?>" data-qarg="feed-param-<?php echo esc_attr( $field_name ); ?>">
				<option value="GREATER_THAN">Greater Than</option>
				<option value="LESS_THAN">Less Than</option>
				<option value="EQUALS">Equals</option>
			</select>
			<input type="hidden" name="feed-param-<?php echo esc_attr( $field_name ); ?>">
		</p>

		<?php $field_name = 'job_published_at'; ?>
		<p class="params opt-param-<?php echo esc_attr( $field_name ); ?>">
			<label for="feed-<?php echo esc_attr( $field_name ); ?>"><strong>&nbsp;</strong>
			</label><span class="feed-param-<?php echo esc_attr( $field_name ); ?>"></span>
			<input type="date" class="regular-text" style="width: 250px" style name="feed-<?php echo esc_attr( $field_name ); ?>" data-qarg="feed-param-<?php echo esc_attr( $field_name ); ?>">
			<input type="hidden" name="feed-param-<?php echo esc_attr( $field_name ); ?>">
		</p>

		<div class="clear"></div>

		<?php $field_name = 'hours'; ?>
		<p class="params opt-param-<?php echo esc_attr( $field_name ); ?>">
			<label for="feed-latlong"><strong><?php _e( 'Job Type(s)', 'gofetch-wpjm' ); ?></strong>
				<span class="tip"><span class="dashicons-before dashicons-editor-help tip-icon bc-tip" data-tooltip="<?php echo esc_attr( __( 'Choose the job types that best suit your job board.', 'gofetch-wpjm' ) ); ?>"></span></span>
			</label><span class="feed-param-<?php echo esc_attr( $field_name ); ?>"></span>
			<?php echo scbForms::input( $field_job_types, array() ); ?>
			<input type="hidden" name="feed-param-<?php echo esc_attr( $field_name ); ?>">
		</p>

		<?php $field_name = 'education'; ?>
		<p class="params opt-param-<?php echo esc_attr( $field_name ); ?>">
			<label for="feed-latlong"><strong><?php _e( 'Job Education', 'gofetch-wpjm' ); ?></strong>
				<span class="tip"><span class="dashicons-before dashicons-editor-help tip-icon bc-tip" data-tooltip="<?php echo esc_attr( __( 'Choose the job education that best suits your job board.', 'gofetch-wpjm' ) ); ?>"></span></span>
			</label><span class="feed-param-<?php echo esc_attr( $field_name ); ?>"></span>
			<?php echo scbForms::input( $field_job_education, array() ); ?>
			<input type="hidden" name="feed-param-<?php echo esc_attr( $field_name ); ?>">
		</p>

		<div class="clear"></div>

		<?php $field_name = 'categories'; ?>
		<p class="params opt-param-<?php echo esc_attr( $field_name ); ?>">
			<label for="feed-latlong"><strong><?php _e( 'Job Categories', 'gofetch-wpjm' ); ?></strong>
				<span class="tip"><span class="dashicons-before dashicons-editor-help tip-icon bc-tip" data-tooltip="<?php echo esc_attr( __( 'Choose the job categories that best suits your job board.', 'gofetch-wpjm' ) ); ?>"></span></span>
			</label><span class="feed-param-<?php echo esc_attr( $field_name ); ?>"></span>
			<?php echo scbForms::input( $field_categories, array() ); ?>
			<input type="hidden" name="feed-param-<?php echo esc_attr( $field_name ); ?>">
		</p>

		<div class="clear"></div>
<?php
	}

	/**
	 * Fetch the API feed.
	 */
	public function fetch_feed( $url ) {
		global $goft_wpjm_options;

		$parts = parse_url( $url );

		$params = array();

		if ( ! empty( $parts['query'] ) ) {
			parse_str( $parts['query'], $params );
		}

		$api_args = array(
			'method'  => 'GET',
			'headers' => array(
				'X-API-KEY'    => $goft_wpjm_options->sourcestack_api_key,
				'Content-Type' => 'application/json',
			),
		);

		// Get the country name from the country code.
		if ( ! empty( $params['country'] ) ) {
			$params['country'] = $this->locales( $params['country'] );
		}

		$api_data = $this->get_api_data( $url, $_xml_data = false, $api_args );

		// @todo: look at the 'X-SOURCESTACK-REQUEST-ID' header for debugging issues.

		if ( is_wp_error( $api_data ) ) {
			return $api_data;
		}

		if ( $error = $this->maybe_raise_error( $api_data, empty( $api_data['data'] ), $url ) ) {
			return $error;
		}

		return $api_data['data'];
	}

	/**
	 * Fetch items from the API feed.
	 */
	public function fetch_feed_items( $items, $url, $provider ) {
		global $goft_wpjm_options;

		$new_items = $sample_item = array();

		$defaults = self::$default_fields;

		foreach ( (array) $items as $job ) {
			$job = wp_parse_args( $job, $defaults );

			$new_item = array();

			$new_item['provider_id'] = $provider['id'];
			$new_item['title']       = sanitize_text_field( $job['job_name'] );
			$new_item['date']        = GoFetch_Importer::get_valid_date( $job['last_indexed'], 'api' );
			$new_item['location']    = sanitize_text_field( $job['job_location'] );

			$new_item['company']     = sanitize_text_field( $job['company_name'] );
			$new_item['company_url'] = esc_url_raw( $job['company_url'] );

			$new_item['logo']        = esc_url( $job['logo_url'] );
			$new_item['category']    = implode( ',', array_map( 'sanitize_text_field', $job['tag_categories'] ) );

			$new_item['description'] = GoFetch_Importer::format_description( $job['post_html'] );
			$new_item['link']        = esc_url_raw( html_entity_decode( $job['post_url'] ) );

			// Others
			$new_item['city']       = sanitize_text_field( $job['city'] );
			$new_item['remote']     = sanitize_text_field( $job['remote'] );
			$new_item['region']     = sanitize_text_field( $job['region'] );
			$new_item['hours']      = sanitize_text_field( $job['hours'] );
			$new_item['seniority']  = sanitize_text_field( $job['seniority'] );
			$new_item['department'] = sanitize_text_field( $job['department'] );

			$new_item = apply_filters( 'goft_wpjm_fetch_feed_item', $new_item, $provider, $url, $job, $defaults );

			// Find the item with the most attributes to use as sample.
			if ( count( array_keys( $new_item ) ) > count( array_keys( $sample_item ) ) ) {
				$sample_item                = $new_item;
				$sample_item['description'] = GoFetch_Importer::shortened_description( $job['post_html'] );
			}

			$sample_item = apply_filters( 'goft_wpjm_fetch_feed_sample_item', $sample_item, $provider, $new_item );

			$new_items[] = $new_item;
		}

		// Clear memory.
		$items = null;

		// __LOG.
		// Maybe log import info.
		$vars = array(
			'context' => 'GOFT :: ITEMS COLLECTED FROM FEED',
			'items'   => count( $new_items ),
		);
		BC_Framework_Debug_Logger::log( $vars, $goft_wpjm_options->debug_log );
		// __END LOG.

		$provider['name'] = 'Job Search | sourcestack';

		return array(
			'provider'    => $provider,
			'items'       => $new_items,
			'sample_item' => $sample_item,
		);
	}

	/**
	 * Retrieves the list of country codes for this provider.
	 */
	protected function locales( $country_code = '' ) {
		$locales = array(
			'AD' => 'Andorra',
			'AE' => 'United Arab Emirates',
			'AF' => 'Afghanistan',
			'AG' => 'Antigua And Barbuda',
			'AI' => 'Anguilla',
			'AL' => 'Albania',
			'AM' => 'Armenia',
			'AO' => 'Angola',
			'AQ' => 'Antarctica',
			'AR' => 'Argentina',
			'AS' => 'American Samoa',
			'AT' => 'Austria',
			'AU' => 'Australia',
			'AW' => 'Aruba',
			'AX' => 'Aland Islands',
			'AZ' => 'Azerbaijan',
			'BA' => 'Bosnia And Herzegovina',
			'BB' => 'Barbados',
			'BD' => 'Bangladesh',
			'BE' => 'Belgium',
			'BF' => 'Burkina Faso',
			'BG' => 'Bulgaria',
			'BH' => 'Bahrain',
			'BI' => 'Burundi',
			'BJ' => 'Benin',
			'BL' => 'Saint Barthelemy',
			'BM' => 'Bermuda',
			'BN' => 'Brunei',
			'BO' => 'Bolivia',
			'BQ' => 'Bonaire, Saint Eustatius And Saba',
			'BR' => 'Brazil',
			'BS' => 'Bahamas',
			'BT' => 'Bhutan',
			'BV' => 'Bouvet Island',
			'BW' => 'Botswana',
			'BY' => 'Belarus',
			'BZ' => 'Belize',
			'CA' => 'Canada',
			'CC' => 'Cocos Islands',
			'CD' => 'Democratic Republic Of The Congo',
			'CF' => 'Central African Republic',
			'CG' => 'Republic Of The Congo',
			'CH' => 'Switzerland',
			'CI' => 'Ivory Coast',
			'CK' => 'Cook Islands',
			'CL' => 'Chile',
			'CM' => 'Cameroon',
			'CN' => 'China',
			'CO' => 'Colombia',
			'CR' => 'Costa Rica',
			'CU' => 'Cuba',
			'CV' => 'Cape Verde',
			'CW' => 'Curacao',
			'CX' => 'Christmas Island',
			'CY' => 'Cyprus',
			'CZ' => 'Czech Republic',
			'DE' => 'Germany',
			'DJ' => 'Djibouti',
			'DK' => 'Denmark',
			'DM' => 'Dominica',
			'DO' => 'Dominican Republic',
			'DZ' => 'Algeria',
			'EC' => 'Ecuador',
			'EE' => 'Estonia',
			'EG' => 'Egypt',
			'EH' => 'Western Sahara',
			'ER' => 'Eritrea',
			'ES' => 'Spain',
			'ET' => 'Ethiopia',
			'FI' => 'Finland',
			'FJ' => 'Fiji',
			'FK' => 'Falkland Islands',
			'FM' => 'Micronesia',
			'FO' => 'Faroe Islands',
			'FR' => 'France',
			'GA' => 'Gabon',
			'UK' => 'United Kingdom',
			'GD' => 'Grenada',
			'GE' => 'Georgia',
			'GF' => 'French Guiana',
			'GG' => 'Guernsey',
			'GH' => 'Ghana',
			'GI' => 'Gibraltar',
			'GL' => 'Greenland',
			'GM' => 'Gambia',
			'GN' => 'Guinea',
			'GP' => 'Guadeloupe',
			'GQ' => 'Equatorial Guinea',
			'GR' => 'Greece',
			'GS' => 'South Georgia And The South Sandwich Islands',
			'GT' => 'Guatemala',
			'GU' => 'Guam',
			'GW' => 'Guinea-Bissau',
			'GY' => 'Guyana',
			'HK' => 'Hong Kong',
			'HM' => 'Heard Island And Mcdonald Islands',
			'HN' => 'Honduras',
			'HR' => 'Croatia',
			'HT' => 'Haiti',
			'HU' => 'Hungary',
			'ID' => 'Indonesia',
			'IE' => 'Ireland',
			'IL' => 'Israel',
			'IM' => 'Isle Of Man',
			'IN' => 'India',
			'IO' => 'British Indian Ocean Territory',
			'IQ' => 'Iraq',
			'IR' => 'Iran',
			'IS' => 'Iceland',
			'IT' => 'Italy',
			'JE' => 'Jersey',
			'JM' => 'Jamaica',
			'JO' => 'Jordan',
			'JP' => 'Japan',
			'KE' => 'Kenya',
			'KG' => 'Kyrgyzstan',
			'KH' => 'Cambodia',
			'KI' => 'Kiribati',
			'KM' => 'Comoros',
			'KN' => 'Saint Kitts And Nevis',
			'KP' => 'North Korea',
			'KR' => 'South Korea',
			'XK' => 'Kosovo',
			'KW' => 'Kuwait',
			'KY' => 'Cayman Islands',
			'KZ' => 'Kazakhstan',
			'LA' => 'Laos',
			'LB' => 'Lebanon',
			'LC' => 'Saint Lucia',
			'LI' => 'Liechtenstein',
			'LK' => 'Sri Lanka',
			'LR' => 'Liberia',
			'LS' => 'Lesotho',
			'LT' => 'Lithuania',
			'LU' => 'Luxembourg',
			'LV' => 'Latvia',
			'LY' => 'Libya',
			'MA' => 'Morocco',
			'MC' => 'Monaco',
			'MD' => 'Moldova',
			'ME' => 'Montenegro',
			'MF' => 'Saint Martin',
			'MG' => 'Madagascar',
			'MH' => 'Marshall Islands',
			'MK' => 'Macedonia',
			'ML' => 'Mali',
			'MM' => 'Myanmar',
			'MN' => 'Mongolia',
			'MO' => 'Macao',
			'MP' => 'Northern Mariana Islands',
			'MQ' => 'Martinique',
			'MR' => 'Mauritania',
			'MS' => 'Montserrat',
			'MT' => 'Malta',
			'MU' => 'Mauritius',
			'MV' => 'Maldives',
			'MW' => 'Malawi',
			'MX' => 'Mexico',
			'MY' => 'Malaysia',
			'MZ' => 'Mozambique',
			'NA' => 'Namibia',
			'NC' => 'New Caledonia',
			'NE' => 'Niger',
			'NF' => 'Norfolk Island',
			'NG' => 'Nigeria',
			'NI' => 'Nicaragua',
			'NL' => 'Netherlands',
			'NO' => 'Norway',
			'NP' => 'Nepal',
			'NR' => 'Nauru',
			'NU' => 'Niue',
			'NZ' => 'New Zealand',
			'OM' => 'Oman',
			'PA' => 'Panama',
			'PE' => 'Peru',
			'PF' => 'French Polynesia',
			'PG' => 'Papua New Guinea',
			'PH' => 'Philippines',
			'PK' => 'Pakistan',
			'PL' => 'Poland',
			'PM' => 'Saint Pierre And Miquelon',
			'PN' => 'Pitcairn',
			'PR' => 'Puerto Rico',
			'PS' => 'Palestinian Territory',
			'PT' => 'Portugal',
			'PW' => 'Palau',
			'PY' => 'Paraguay',
			'QA' => 'Qatar',
			'RE' => 'Reunion',
			'RO' => 'Romania',
			'RS' => 'Serbia',
			'RU' => 'Russia',
			'RW' => 'Rwanda',
			'SA' => 'Saudi Arabia',
			'SB' => 'Solomon Islands',
			'SC' => 'Seychelles',
			'SD' => 'Sudan',
			'SS' => 'South Sudan',
			'SE' => 'Sweden',
			'SG' => 'Singapore',
			'SH' => 'Saint Helena',
			'SI' => 'Slovenia',
			'SJ' => 'Svalbard And Jan Mayen',
			'SK' => 'Slovakia',
			'SL' => 'Sierra Leone',
			'SM' => 'San Marino',
			'SN' => 'Senegal',
			'SO' => 'Somalia',
			'SR' => 'Suriname',
			'ST' => 'Sao Tome And Principe',
			'SV' => 'El Salvador',
			'SX' => 'Sint Maarten',
			'SY' => 'Syria',
			'SZ' => 'Swaziland',
			'TC' => 'Turks And Caicos Islands',
			'TD' => 'Chad',
			'TF' => 'French Southern Territories',
			'TG' => 'Togo',
			'TH' => 'Thailand',
			'TJ' => 'Tajikistan',
			'TK' => 'Tokelau',
			'TL' => 'East Timor',
			'TM' => 'Turkmenistan',
			'TN' => 'Tunisia',
			'TO' => 'Tonga',
			'TR' => 'Turkey',
			'TT' => 'Trinidad And Tobago',
			'TV' => 'Tuvalu',
			'TW' => 'Taiwan',
			'TZ' => 'Tanzania',
			'UA' => 'Ukraine',
			'UG' => 'Uganda',
			'UM' => 'United States Minor Outlying Islands',
			'US' => 'United States',
			'UY' => 'Uruguay',
			'UZ' => 'Uzbekistan',
			'VA' => 'Vatican',
			'VC' => 'Saint Vincent And The Grenadines',
			'VE' => 'Venezuela',
			'VG' => 'British Virgin Islands',
			'VI' => 'US Virgin Islands',
			'VN' => 'Vietnam',
			'VU' => 'Vanuatu',
			'WF' => 'Wallis And Futuna',
			'WS' => 'Samoa',
			'YE' => 'Yemen',
			'YT' => 'Mayotte',
			'ZA' => 'South Africa',
			'ZM' => 'Zambia',
			'ZW' => 'Zimbabwe',
			'CS' => 'Serbia And Montenegro',
		);

		if ( ! empty( $country_code ) ) {
			return $locales[ $country_code ];
		}

		asort( $locales );

		unset( $locales['US'] );
		unset( $locales['UK'] );

		$locales = array_combine( array_values( $locales ), array_values( $locales ) );

		$locales = array(
			''   => 'Any (Recommended for Remote jobs)',
			'United States' => 'United States',
			'United Kingdom' => 'United Kingdom',
			) + $locales;


		return $locales;
	}

	protected function regions() {
		$regions = array(
			'Alabama'                      => 'Alabama',
			'Alaska'                       => 'Alaska',
			'Arizona'                      => 'Arizona',
			'Arkansas'                     => 'Arkansas',
			'California'                   => 'California',
			'Colorado'                     => 'Colorado',
			'Connecticut'                  => 'Connecticut',
			'Delaware'                     => 'Delaware',
			'District of Columbia'         => 'District of Columbia',
			'Florida'                      => 'Florida',
			'Georgia'                      => 'Georgia',
			'Hawaii'                       => 'Hawaii',
			'Idaho'                        => 'Idaho',
			'Illinois'                     => 'Illinois',
			'Indiana'                      => 'Indiana',
			'Iowa'                         => 'Iowa',
			'Kansas'                       => 'Kansas',
			'Kentucky'                     => 'Kentucky',
			'Louisiana'                    => 'Louisiana',
			'Maine'                        => 'Maine',
			'Maryland'                     => 'Maryland',
			'Massachusetts'                => 'Massachusetts',
			'Michigan'                     => 'Michigan',
			'Minnesota'                    => 'Minnesota',
			'Mississippi'                  => 'Mississippi',
			'Missouri'                     => 'Missouri',
			'Montana'                      => 'Montana',
			'Nebraska'                     => 'Nebraska',
			'Nevada'                       => 'Nevada',
			'New Hampshire'                => 'New Hampshire',
			'New Jersey'                   => 'New Jersey',
			'New Mexico'                   => 'New Mexico',
			'New York'                     => 'New York',
			'North Carolina'               => 'North Carolina',
			'North Dakota'                 => 'North Dakota',
			'Ohio'                         => 'Ohio',
			'Oklahoma'                     => 'Oklahoma',
			'Oregon'                       => 'Oregon',
			'Pennsylvania'                 => 'Pennsylvania',
			'Rhode Island'                 => 'Rhode Island',
			'South Carolina'               => 'South Carolina',
			'South Dakota'                 => 'South Dakota',
			'Tennessee'                    => 'Tennessee',
			'Texas'                        => 'Texas',
			'Utah'                         => 'Utah',
			'Vermont'                      => 'Vermont',
			'Virginia'                     => 'Virginia',
			'Washington'                   => 'Washington',
			'West Virginia'                => 'West Virginia',
			'Wisconsin'                    => 'Wisconsin',
			'Wyoming'                      => 'Wyoming',
			'American Samoa'               => 'American Samoa',
			'Guam'                         => 'Guam',
			'Northern Mariana Islands'     => 'Northern Mariana Islands',
			'Puerto Rico'                  => 'Puerto Rico',
			'U.S. Virgin Islands'          => 'U.S. Virgin Islands',
			'Alberta'                      => 'Alberta',
			'British Columbia'             => 'British Columbia',
			'Manitoba'                     => 'Manitoba',
			'New Brunswick'                => 'New Brunswick',
			'Newfoundland and Labrador'    => 'Newfoundland and Labrador',
			'Northwest Territories'        => 'Northwest Territories',
			'Nova Scotia'                  => 'Nova Scotia',
			'Nunavut'                      => 'Nunavut',
			'Ontario'                      => 'Ontario',
			'Prince Edward Island'         => 'Prince Edward Island',
			'Quebec'                       => 'Quebec',
			'Saskatchewan'                 => 'Saskatchewan',
			'Yukon'                        => 'Yukon',
			'Northern Territory'           => 'Northern Territory',
			'Australian Capital Territory' => 'Australian Capital Territory',
			'Western Australia'            => 'Western Australia',
			'Tasmania'                     => 'Tasmania',
			'South Australia'              => 'South Australia',
			'Victoria'                     => 'Victoria',
			'Queensland'                   => 'Queensland',
			'New South Wales'              => 'New South Wales',
			'East of England'              => 'East of England',
			'West Midlands'                => 'West Midlands',
			'Yorkshire and the Humber'     => 'Yorkshire and the Humber',
			'East Midlands'                => 'East Midlands',
			'Bedfordshire'                 => 'Bedfordshire',
			'Berkshire'                    => 'Berkshire',
			'Buckinghamshire'              => 'Buckinghamshire',
			'Cambridgeshire'               => 'Cambridgeshire',
			'Cheshire'                     => 'Cheshire',
			'Cornwall'                     => 'Cornwall',
			'Cumberland'                   => 'Cumberland',
			'Derbyshire'                   => 'Derbyshire',
			'Devon'                        => 'Devon',
			'Dorset'                       => 'Dorset',
			'Durham'                       => 'Durham',
			'Essex'                        => 'Essex',
			'Gloucestershire'              => 'Gloucestershire',
			'Hampshire'                    => 'Hampshire',
			'Herefordshire'                => 'Herefordshire',
			'Hertfordshire'                => 'Hertfordshire',
			'Huntingdonshire'              => 'Huntingdonshire',
			'Kent'                         => 'Kent',
			'Lancashire'                   => 'Lancashire',
			'Leicestershire'               => 'Leicestershire',
			'Lincolnshire'                 => 'Lincolnshire',
			'Middlesex'                    => 'Middlesex',
			'Norfolk'                      => 'Norfolk',
			'Northamptonshire'             => 'Northamptonshire',
			'Northumberland'               => 'Northumberland',
			'Nottinghamshire'              => 'Nottinghamshire',
			'Oxfordshire'                  => 'Oxfordshire',
			'Rutland'                      => 'Rutland',
			'Shropshire'                   => 'Shropshire',
			'Somerset'                     => 'Somerset',
			'Staffordshire'                => 'Staffordshire',
			'Suffolk'                      => 'Suffolk',
			'Surrey'                       => 'Surrey',
			'Sussex'                       => 'Sussex',
			'Warwickshire'                 => 'Warwickshire',
			'Westmorland'                  => 'Westmorland',
			'Wiltshire'                    => 'Wiltshire',
			'Worcestershire'               => 'Worcestershire',
			'Yorkshire'                    => 'Yorkshire',
			'Auvergne-Rhône-Alpes'         => 'Auvergne-Rhône-Alpes',
			'Bourgogne-Franche-Comté'      => 'Bourgogne-Franche-Comté',
			'Bretagne'                     => 'Bretagne',
			'Centre-Val de Loire'          => 'Centre-Val de Loire',
			'Corse'                        => 'Corse',
			'Grand-Est'                    => 'Grand-Est',
			'Hauts-de-France'              => 'Hauts-de-France',
			'Île-de-France'                => 'Île-de-France',
			'Normandie'                    => 'Normandie',
			'Nouvelle-Aquitaine'           => 'Nouvelle-Aquitaine',
			'Occitanie'                    => 'Occitanie',
			'Pays-de-la-Loire'             => 'Pays-de-la-Loire',
			'Provence-Alpes-Côte-d’Azur'   => 'Provence-Alpes-Côte-d’Azur',
			'Baden-Württemberg'            => 'Baden-Württemberg',
			'Bavaria'                      => 'Bavaria',
			'Berlin'                       => 'Berlin',
			'Brandenburg'                  => 'Brandenburg',
			'Bremen'                       => 'Bremen',
			'Hamburg'                      => 'Hamburg',
			'Hesse'                        => 'Hesse',
			'Lower Saxony'                 => 'Lower Saxony',
			'Mecklenburg-Vorpommern'       => 'Mecklenburg-Vorpommern',
			'North Rhine-Westphalia'       => 'North Rhine-Westphalia',
			'Rhineland-Palatinate'         => 'Rhineland-Palatinate',
			'Saarland'                     => 'Saarland',
			'Saxony'                       => 'Saxony',
			'Saxony-Anhalt'                => 'Saxony-Anhalt',
			'Schleswig-Holstein'           => 'Schleswig-Holstein',
			'Thuringia'                    => 'Thuringia',

		);
		return $regions;
	}

	protected function regions_country_map() {
		$regions = array(
			'Alabama'                      => 'US',
			'Alaska'                       => 'US',
			'Arizona'                      => 'US',
			'Arkansas'                     => 'US',
			'California'                   => 'US',
			'Colorado'                     => 'US',
			'Connecticut'                  => 'US',
			'Delaware'                     => 'US',
			'District of Columbia'         => 'US',
			'Florida'                      => 'US',
			'Georgia'                      => 'US',
			'Hawaii'                       => 'US',
			'Idaho'                        => 'US',
			'Illinois'                     => 'US',
			'Indiana'                      => 'US',
			'Iowa'                         => 'US',
			'Kansas'                       => 'US',
			'Kentucky'                     => 'US',
			'Louisiana'                    => 'US',
			'Maine'                        => 'US',
			'Maryland'                     => 'US',
			'Massachusetts'                => 'US',
			'Michigan'                     => 'US',
			'Minnesota'                    => 'US',
			'Mississippi'                  => 'US',
			'Missouri'                     => 'US',
			'Montana'                      => 'US',
			'Nebraska'                     => 'US',
			'Nevada'                       => 'US',
			'New Hampshire'                => 'US',
			'New Jersey'                   => 'US',
			'New Mexico'                   => 'US',
			'New York'                     => 'US',
			'North Carolina'               => 'US',
			'North Dakota'                 => 'US',
			'Ohio'                         => 'US',
			'Oklahoma'                     => 'US',
			'Oregon'                       => 'US',
			'Pennsylvania'                 => 'US',
			'Rhode Island'                 => 'US',
			'South Carolina'               => 'US',
			'South Dakota'                 => 'US',
			'Tennessee'                    => 'US',
			'Texas'                        => 'US',
			'Utah'                         => 'US',
			'Vermont'                      => 'US',
			'Virginia'                     => 'US',
			'Washington'                   => 'US',
			'West Virginia'                => 'US',
			'Wisconsin'                    => 'US',
			'Wyoming'                      => 'US',
			'American Samoa'               => 'US',
			'Guam'                         => 'US',
			'Northern Mariana Islands'     => 'US',
			'Puerto Rico'                  => 'US',
			'U.S. Virgin Islands'          => 'US',
			'Alberta'                      => 'CA',
			'British Columbia'             => 'CA',
			'Manitoba'                     => 'CA',
			'New Brunswick'                => 'CA',
			'Newfoundland and Labrador'    => 'CA',
			'Northwest Territories'        => 'CA',
			'Nova Scotia'                  => 'CA',
			'Nunavut'                      => 'CA',
			'Ontario'                      => 'CA',
			'Prince Edward Island'         => 'CA',
			'Quebec'                       => 'CA',
			'Saskatchewan'                 => 'CA',
			'Yukon'                        => 'CA',
			'Northern Territory'           => 'AU',
			'Australian Capital Territory' => 'AU',
			'Western Australia'            => 'AU',
			'Tasmania'                     => 'AU',
			'South Australia'              => 'AU',
			'Victoria'                     => 'AU',
			'Queensland'                   => 'AU',
			'New South Wales'              => 'AU',
			'East of England'              => 'UK',
			'West Midlands'                => 'UK',
			'Yorkshire and the Humber'     => 'UK',
			'East Midlands'                => 'UK',
			'Bedfordshire'                 => 'UK',
			'Berkshire'                    => 'UK',
			'Buckinghamshire'              => 'UK',
			'Cambridgeshire'               => 'UK',
			'Cheshire'                     => 'UK',
			'Cornwall'                     => 'UK',
			'Cumberland'                   => 'UK',
			'Derbyshire'                   => 'UK',
			'Devon'                        => 'UK',
			'Dorset'                       => 'UK',
			'Durham'                       => 'UK',
			'Essex'                        => 'UK',
			'Gloucestershire'              => 'UK',
			'Hampshire'                    => 'UK',
			'Herefordshire'                => 'UK',
			'Hertfordshire'                => 'UK',
			'Huntingdonshire'              => 'UK',
			'Kent'                         => 'UK',
			'Lancashire'                   => 'UK',
			'Leicestershire'               => 'UK',
			'Lincolnshire'                 => 'UK',
			'Middlesex'                    => 'UK',
			'Norfolk'                      => 'UK',
			'Northamptonshire'             => 'UK',
			'Northumberland'               => 'UK',
			'Nottinghamshire'              => 'UK',
			'Oxfordshire'                  => 'UK',
			'Rutland'                      => 'UK',
			'Shropshire'                   => 'UK',
			'Somerset'                     => 'UK',
			'Staffordshire'                => 'UK',
			'Suffolk'                      => 'UK',
			'Surrey'                       => 'UK',
			'Sussex'                       => 'UK',
			'Warwickshire'                 => 'UK',
			'Westmorland'                  => 'UK',
			'Wiltshire'                    => 'UK',
			'Worcestershire'               => 'UK',
			'Yorkshire'                    => 'UK',
			'Auvergne-Rhône-Alpes'         => 'FR',
			'Bourgogne-Franche-Comté'      => 'FR',
			'Bretagne'                     => 'FR',
			'Centre-Val de Loire'          => 'FR',
			'Corse'                        => 'FR',
			'Grand-Est'                    => 'FR',
			'Hauts-de-France'              => 'FR',
			'Île-de-France'                => 'FR',
			'Normandie'                    => 'FR',
			'Nouvelle-Aquitaine'           => 'FR',
			'Occitanie'                    => 'FR',
			'Pays-de-la-Loire'             => 'FR',
			'Provence-Alpes-Côte-d’Azur'   => 'FR',
			'Baden-Württemberg'            => 'DE',
			'Bavaria'                      => 'DE',
			'Berlin'                       => 'DE',
			'Brandenburg'                  => 'DE',
			'Bremen'                       => 'DE',
			'Hamburg'                      => 'DE',
			'Hesse'                        => 'DE',
			'Lower Saxony'                 => 'DE',
			'Mecklenburg-Vorpommern'       => 'DE',
			'North Rhine-Westphalia'       => 'DE',
			'Rhineland-Palatinate'         => 'DE',
			'Saarland'                     => 'DE',
			'Saxony'                       => 'DE',
			'Saxony-Anhalt'                => 'DE',
			'Schleswig-Holstein'           => 'DE',
			'Thuringia'                    => 'DE',
		);

		return $regions;
	}

	public static function languages() {

		$languages = array(
			'aa' => 'Afaraf',
			'ab' => 'аҧсуа бызшәа, аҧсшәа',
			'ae' => 'avesta',
			'af' => 'Afrikaans',
			'ak' => 'Akan',
			'am' => 'አማርኛ',
			'an' => 'aragonés',
			'ar' => 'العربية',
			'as' => 'অসমীয়া',
			'av' => 'авар мацӀ, магӀарул мацӀ',
			'ay' => 'aymar aru',
			'az' => 'azərbaycan dili',
			'ba' => 'башҡорт теле',
			'be' => 'беларуская мова',
			'bg' => 'български език',
			'bh' => 'भोजपुरी',
			'bi' => 'Bislama',
			'bm' => 'bamanankan',
			'bn' => 'বাংলা',
			'bo' => 'བོད་ཡིག',
			'br' => 'brezhoneg',
			'bs' => 'bosanski jezik',
			'ca' => 'català, valencià',
			'ce' => 'нохчийн мотт',
			'ch' => 'Chamoru',
			'co' => 'corsu, lingua corsa',
			'cr' => 'ᓀᐦᐃᔭᐍᐏᐣ',
			'cs' => 'čeština, český jazyk',
			'cu' => 'ѩзыкъ словѣньскъ',
			'cv' => 'чӑваш чӗлхи',
			'cy' => 'Cymraeg',
			'da' => 'dansk',
			'de' => 'Deutsch',
			'dv' => 'ދިވެހި',
			'dz' => 'རྫོང་ཁ',
			'ee' => 'Eʋegbe',
			'el' => 'ελληνικά',
			'en' => 'English',
			'eo' => 'Esperanto',
			'es' => 'Español',
			'et' => 'eesti, eesti keel',
			'eu' => 'euskara, euskera',
			'fa' => 'فارسی',
			'ff' => 'Fulfulde, Pulaar, Pular',
			'fi' => 'suomi, suomen kieli',
			'fj' => 'vosa Vakaviti',
			'fo' => 'føroyskt',
			'fr' => 'français, langue française',
			'fy' => 'Frysk',
			'ga' => 'Gaeilge',
			'gd' => 'Gàidhlig',
			'gl' => 'Galego',
			'gn' => 'Avañe\'ẽ',
			'gu' => 'ગુજરાતી',
			'gv' => 'Gaelg, Gailck',
			'ha' => '(Hausa) هَوُسَ',
			'he' => 'עברית',
			'hi' => 'हिन्दी, हिंदी',
			'ho' => 'Hiri Motu',
			'hr' => 'hrvatski jezik',
			'ht' => 'Kreyòl ayisyen',
			'hu' => 'magyar',
			'hy' => 'Հայերեն',
			'hz' => 'Otjiherero',
			'ia' => 'Interlingua',
			'id' => 'Bahasa Indonesia',
			'ie' => '(originally:) Occidental, (after WWII:) Interlingue',
			'ig' => 'Asụsụ Igbo',
			'ii' => 'ꆈꌠ꒿ Nuosuhxop',
			'ik' => 'Iñupiaq, Iñupiatun',
			'io' => 'Ido',
			'is' => 'Íslenska',
			'it' => 'Italiano',
			'iu' => 'ᐃᓄᒃᑎᑐᑦ',
			'ja' => '日本語 (にほんご)',
			'jv' => 'ꦧꦱꦗꦮ, Basa Jawa',
			'ka' => 'ქართული',
			'kg' => 'Kikongo',
			'ki' => 'Gĩkũyũ',
			'kj' => 'Kuanyama',
			'kk' => 'қазақ тілі',
			'kl' => 'kalaallisut, kalaallit oqaasii',
			'km' => 'ខ្មែរ, ខេមរភាសា, ភាសាខ្មែរ',
			'kn' => 'ಕನ್ನಡ',
			'ko' => '한국어',
			'kr' => 'Kanuri',
			'ks' => 'कश्मीरी, كشميري‎',
			'ku' => 'Kurdî, کوردی‎',
			'kv' => 'коми кыв',
			'kw' => 'Kernewek',
			'ky' => 'Кыргызча, Кыргыз тили',
			'la' => 'latine, lingua latina',
			'lb' => 'Lëtzebuergesch',
			'lg' => 'Luganda',
			'li' => 'Limburgs',
			'ln' => 'Lingála',
			'lo' => 'ພາສາລາວ',
			'lt' => 'lietuvių kalba',
			'lu' => 'Kiluba',
			'lv' => 'latviešu valoda',
			'mg' => 'fiteny malagasy',
			'mh' => 'Kajin M̧ajeļ',
			'mi' => 'te reo Māori',
			'mk' => 'македонски јазик',
			'ml' => 'മലയാളം',
			'mn' => 'Монгол хэл',
			'mr' => 'मराठी',
			'ms' => 'Bahasa Melayu, بهاس ملايو‎',
			'mt' => 'Malti',
			'my' => 'ဗမာစာ',
			'na' => 'Dorerin Naoero',
			'nb' => 'Norsk Bokmål',
			'nd' => 'isiNdebele',
			'ne' => 'नेपाली',
			'ng' => 'Owambo',
			'nl' => 'Nederlands, Vlaams',
			'nn' => 'Norsk Nynorsk',
			'no' => 'Norsk',
			'nr' => 'isiNdebele',
			'nv' => 'Diné bizaad',
			'ny' => 'chiCheŵa, chinyanja',
			'oc' => 'occitan, lenga d\'òc',
			'oj' => 'ᐊᓂᔑᓈᐯᒧᐎᓐ',
			'om' => 'Afaan Oromoo',
			'or' => 'ଓଡ଼ିଆ',
			'os' => 'ирон æвзаг',
			'pa' => 'ਪੰਜਾਬੀ, پنجابی‎',
			'pi' => 'पालि, पाळि',
			'pl' => 'język polski, polszczyzna',
			'ps' => 'پښتو',
			'pt' => 'Português',
			'qu' => 'Runa Simi, Kichwa',
			'rm' => 'Rumantsch Grischun',
			'rn' => 'Ikirundi',
			'ro' => 'Română',
			'ru' => 'русский',
			'rw' => 'Ikinyarwanda',
			'sa' => 'संस्कृतम्',
			'sc' => 'sardu',
			'sd' => 'सिन्धी, سنڌي، سندھی‎',
			'se' => 'Davvisámegiella',
			'sg' => 'yângâ tî sängö',
			'si' => 'සිංහල',
			'sk' => 'Slovenčina, Slovenský jazyk',
			'sl' => 'Slovenski jezik, Slovenščina',
			'sm' => 'gagana fa\'a Samoa',
			'sn' => 'chiShona',
			'so' => 'Soomaaliga, af Soomaali',
			'sq' => 'Shqip',
			'sr' => 'српски језик',
			'ss' => 'SiSwati',
			'st' => 'Sesotho',
			'su' => 'Basa Sunda',
			'sv' => 'Svenska',
			'sw' => 'Kiswahili',
			'ta' => 'தமிழ்',
			'te' => 'తెలుగు',
			'tg' => 'тоҷикӣ, toçikī, تاجیکی‎',
			'th' => 'ไทย',
			'ti' => 'ትግርኛ',
			'tk' => 'Türkmen, Түркмен',
			'tl' => 'Wikang Tagalog',
			'tn' => 'Setswana',
			'to' => 'Faka Tonga',
			'tr' => 'Türkçe',
			'ts' => 'Xitsonga',
			'tt' => 'татар теле, tatar tele',
			'tw' => 'Twi',
			'ty' => 'Reo Tahiti',
			'ug' => 'ئۇيغۇرچە‎, Uyghurche',
			'uk' => 'Українська',
			'ur' => 'اردو',
			'uz' => 'Oʻzbek, Ўзбек, أۇزبېك‎',
			've' => 'Tshivenḓa',
			'vi' => 'Tiếng Việt',
			'vo' => 'Volapük',
			'wa' => 'Walon',
			'wo' => 'Wollof',
			'xh' => 'isiXhosa',
			'yi' => 'ייִדיש',
			'yo' => 'Yorùbá',
			'za' => 'Saɯ cueŋƅ, Saw cuengh',
			'zh' => '中文 (Zhōngwén), 汉语, 漢語',
			'zu' => 'isiZulu',
		);
		return $languages;
	}

	/**
	 * Job categories for this provider.
	 */
	public static function categories() {

		$categories = array(
			'3D'                                                          => '3D',
			'Accounting'                                                  => 'Accounting',
			'Ad Network'                                                  => 'Ad Network',
			'Adult Content'                                               => 'Adult Content',
			'Adventures'                                                  => 'Adventures',
			'Advertising'                                                 => 'Advertising',
			'Affiliate Marketing'                                         => 'Affiliate Marketing',
			'Agency'                                                      => 'Agency',
			'AI'                                                          => 'AI',
			'Airlines & Aerospace'                                        => 'Airlines & Aerospace',
			'Alternative Medicine'                                        => 'Alternative Medicine',
			'Android'                                                     => 'Android',
			'Animals'                                                     => 'Animals',
			'Animation'                                                   => 'Animation',
			'Anti-Aging Products'                                         => 'Anti-Aging Products',
			'APIs'                                                        => 'APIs',
			'Apparel & Fashion'                                           => 'Apparel & Fashion',
			'Apple-Related'                                               => 'Apple-Related',
			'Application Programming Interfaces'                          => 'Application Programming Interfaces',
			'AR & VR'                                                     => 'AR & VR',
			'Architecture & Planning'                                     => 'Architecture & Planning',
			'Art & Entertainment'                                         => 'Art & Entertainment',
			'Artifical Intelligence'                                      => 'Artifical Intelligence',
			'Arts & Crafts'                                               => 'Arts & Crafts',
			'Athletic Apparel'                                            => 'Athletic Apparel',
			'Audio'                                                       => 'Audio',
			'Augmented Reality & Virtual Reality'                         => 'Augmented Reality & Virtual Reality',
			'Automotive & Vehicles'                                       => 'Automotive & Vehicles',
			'B2B'                                                         => 'B2B',
			'Banking'                                                     => 'Banking',
			'Beach Apparel'                                               => 'Beach Apparel',
			'Beauty & Cosmetics'                                          => 'Beauty & Cosmetics',
			'Bicycles & Cycling'                                          => 'Bicycles & Cycling',
			'Big Data'                                                    => 'Big Data',
			'BioTech'                                                     => 'BioTech',
			'Blogging'                                                    => 'Blogging',
			'Books'                                                       => 'Books',
			'Branding'                                                    => 'Branding',
			'Broadcast Media'                                             => 'Broadcast Media',
			'Building Materials'                                          => 'Building Materials',
			'Business'                                                    => 'Business',
			'Business Intelligence'                                       => 'Business Intelligence',
			'Business Supplies & Equipment'                               => 'Business Supplies & Equipment',
			'Business to Business'                                        => 'Business to Business',
			'Calendaring'                                                 => 'Calendaring',
			'Capital Markets'                                             => 'Capital Markets',
			'Career Resources'                                            => 'Career Resources',
			'Ceramics & Concrete'                                         => 'Ceramics & Concrete',
			'Charities & Nonprofits'                                      => 'Charities & Nonprofits',
			'Chat System'                                                 => 'Chat System',
			'Chemicals'                                                   => 'Chemicals',
			'China-Related'                                               => 'China-Related',
			'Civic & Social Organization'                                 => 'Civic & Social Organization',
			'Civil Engineering'                                           => 'Civil Engineering',
			'Classifieds'                                                 => 'Classifieds',
			'Cleaning Services'                                           => 'Cleaning Services',
			'Cleantech'                                                   => 'Cleantech',
			'Cloud Computing'                                             => 'Cloud Computing',
			'CMS'                                                         => 'CMS',
			'Coffee & Tea'                                                => 'Coffee & Tea',
			'Collaboration'                                               => 'Collaboration',
			'Commercial Fishing'                                          => 'Commercial Fishing',
			'Commercial Real Estate'                                      => 'Commercial Real Estate',
			'Communications Platform as a Service'                        => 'Communications Platform as a Service',
			'Compliance'                                                  => 'Compliance',
			'Computer Games'                                              => 'Computer Games',
			'Computer Hardware'                                           => 'Computer Hardware',
			'Computer Networking'                                         => 'Computer Networking',
			'Conferences'                                                 => 'Conferences',
			'Construction'                                                => 'Construction',
			'Consulting'                                                  => 'Consulting',
			'Consulting, Recruitment'                                     => 'Consulting, Recruitment',
			'Consumer Electronics'                                        => 'Consumer Electronics',
			'Consumer Goods'                                              => 'Consumer Goods',
			'Content Management System'                                   => 'Content Management System',
			'Copywriting'                                                 => 'Copywriting',
			'CPaaS'                                                       => 'CPaaS',
			'CRM'                                                         => 'CRM',
			'Crowdfunding'                                                => 'Crowdfunding',
			'Crowdsourcing'                                               => 'Crowdsourcing',
			'Crypto'                                                      => 'Crypto',
			'Cryptocurrencies and related blockchain technologies'        => 'Cryptocurrencies and related blockchain technologies',
			'Custom-Made'                                                 => 'Custom-Made',
			'Customer Relationship Management'                            => 'Customer Relationship Management',
			'Cybersecurity'                                               => 'Cybersecurity',
			'Dairy'                                                       => 'Dairy',
			'Data Backup'                                                 => 'Data Backup',
			'Data Storage'                                                => 'Data Storage',
			'Dating & Romance'                                            => 'Dating & Romance',
			'Deal Site'                                                   => 'Deal Site',
			'Dentistry'                                                   => 'Dentistry',
			'Design'                                                      => 'Design',
			'Developer Tools'                                             => 'Developer Tools',
			'DevOps'                                                      => 'DevOps',
			'Digital Marketing'                                           => 'Digital Marketing',
			'Dispute Resolution'                                          => 'Dispute Resolution',
			'Documentation'                                               => 'Documentation',
			'Dogs'                                                        => 'Dogs',
			'Drones'                                                      => 'Drones',
			'Eco-Friendly Products'                                       => 'Eco-Friendly Products',
			'eCom'                                                        => 'eCom',
			'ecommerce'                                                   => 'ecommerce',
			'Education'                                                   => 'Education',
			'Education Management'                                        => 'Education Management',
			'eLearning'                                                   => 'eLearning',
			'Electronics Manufacturing'                                   => 'Electronics Manufacturing',
			'Email Marketing'                                             => 'Email Marketing',
			'Energy'                                                      => 'Energy',
			'England-Related'                                             => 'England-Related',
			'Enterprise Resource Planning'                                => 'Enterprise Resource Planning',
			'Entertainment'                                               => 'Entertainment',
			'Environmental Services'                                      => 'Environmental Services',
			'ERP'                                                         => 'ERP',
			'eSignature'                                                  => 'eSignature',
			'Events Services'                                             => 'Events Services',
			'Eye & Lip Products'                                          => 'Eye & Lip Products',
			'Face Masks'                                                  => 'Face Masks',
			'Facebook-Related'                                            => 'Facebook-Related',
			'Facilities Services'                                         => 'Facilities Services',
			'Family'                                                      => 'Family',
			'Family & Parenting'                                          => 'Family & Parenting',
			'Farming & Agriculture'                                       => 'Farming & Agriculture',
			'Fashion'                                                     => 'Fashion',
			'Financial Services'                                          => 'Financial Services',
			'Fine Art'                                                    => 'Fine Art',
			'FinTech'                                                     => 'FinTech',
			'Firearms & Accessories'                                      => 'Firearms & Accessories',
			'Food & Beverage'                                             => 'Food & Beverage',
			'Freelancing'                                                 => 'Freelancing',
			'Fundraising'                                                 => 'Fundraising',
			'Furniture'                                                   => 'Furniture',
			'Gambling & Casinos'                                          => 'Gambling & Casinos',
			'Games'                                                       => 'Games',
			'Gaming'                                                      => 'Gaming',
			'Garage Door Services'                                        => 'Garage Door Services',
			'Gardening'                                                   => 'Gardening',
			'General Analytics'                                           => 'General Analytics',
			'General Wellness'                                            => 'General Wellness',
			'Gig Work'                                                    => 'Gig Work',
			'Glass Production'                                            => 'Glass Production',
			'Global Positioning System'                                   => 'Global Positioning System',
			'Google-Related'                                              => 'Google-Related',
			'Government'                                                  => 'Government',
			'Government Relations'                                        => 'Government Relations',
			'GPS'                                                         => 'GPS',
			'Graphic Design'                                              => 'Graphic Design',
			'Hair Extension'                                              => 'Hair Extension',
			'Hardware'                                                    => 'Hardware',
			'Hardware Peripherals'                                        => 'Hardware Peripherals',
			'Health & Fitness'                                            => 'Health & Fitness',
			'Healthcare'                                                  => 'Healthcare',
			'Healthcare Providers'                                        => 'Healthcare Providers',
			'Healthtech'                                                  => 'Healthtech',
			'Higher Education'                                            => 'Higher Education',
			'Hobbies & Leisure'                                           => 'Hobbies & Leisure',
			'Home'                                                        => 'Home',
			'Home Cleaning'                                               => 'Home Cleaning',
			'Home Goods & Decor'                                          => 'Home Goods & Decor',
			'Home Improvement'                                            => 'Home Improvement',
			'Hospital'                                                    => 'Hospital',
			'Hospitality'                                                 => 'Hospitality',
			'Hosting'                                                     => 'Hosting',
			'Hotel'                                                       => 'Hotel',
			'Household Products'                                          => 'Household Products',
			'HR'                                                          => 'HR',
			'Human Resources'                                             => 'Human Resources',
			'Huntin & Fishin'                                             => 'Huntin & Fishin',
			'IaaS'                                                        => 'IaaS',
			'Import & Export'                                             => 'Import & Export',
			'India-Related'                                               => 'India-Related',
			'Industrial Automation'                                       => 'Industrial Automation',
			'Information Technology'                                      => 'Information Technology',
			'Infrastructure-as-a-Service'                                 => 'Infrastructure-as-a-Service',
			'Insurance'                                                   => 'Insurance',
			'International Affairs'                                       => 'International Affairs',
			'International Trade & Development'                           => 'International Trade & Development',
			'Internet of Things'                                          => 'Internet of Things',
			'Investment Banking'                                          => 'Investment Banking',
			'Investment Management'                                       => 'Investment Management',
			'iOS'                                                         => 'iOS',
			'IoT'                                                         => 'IoT',
			'iPhone Operating System'                                     => 'iPhone Operating System',
			'IT'                                                          => 'IT',
			'Jewelry'                                                     => 'Jewelry',
			'Job Board'                                                   => 'Job Board',
			'Job Search'                                                  => 'Job Search',
			'Kids Products'                                               => 'Kids Products',
			'Law & Politics'                                              => 'Law & Politics',
			'Law Enforcement'                                             => 'Law Enforcement',
			'Lead Generation'                                             => 'Lead Generation',
			'Legal Services'                                              => 'Legal Services',
			'Lending'                                                     => 'Lending',
			'Libraries'                                                   => 'Libraries',
			'Lingerie & Undergarments'                                    => 'Lingerie & Undergarments',
			'Local Services'                                              => 'Local Services',
			'Logistics & Supply Chain'                                    => 'Logistics & Supply Chain',
			'Logo Design'                                                 => 'Logo Design',
			'Lotions & Moisturizers'                                      => 'Lotions & Moisturizers',
			'Low-Cost'                                                    => 'Low-Cost',
			'Luxury Goods'                                                => 'Luxury Goods',
			'Machine Learning'                                            => 'Machine Learning',
			'Machinery'                                                   => 'Machinery',
			'Makeup Products'                                             => 'Makeup Products',
			'Management Consulting'                                       => 'Management Consulting',
			'Manufacturing'                                               => 'Manufacturing',
			'Maps'                                                        => 'Maps',
			'Marijuana Products'                                          => 'Marijuana Products',
			'Maritime'                                                    => 'Maritime',
			'Market Research'                                             => 'Market Research',
			'Marketing'                                                   => 'Marketing',
			'Marketing Technology'                                        => 'Marketing Technology',
			'Marketplace'                                                 => 'Marketplace',
			'MarTech'                                                     => 'MarTech',
			'Maternity & Baby'                                            => 'Maternity & Baby',
			'Meat Alternatives'                                           => 'Meat Alternatives',
			'Mechanical & Industrial Engineering'                         => 'Mechanical & Industrial Engineering',
			'Media'                                                       => 'Media',
			'Media Services'                                              => 'Media Services',
			'Medical Diagnostics'                                         => 'Medical Diagnostics',
			'Mental Healthcare'                                           => 'Mental Healthcare',
			'Military'                                                    => 'Military',
			'Milk Alternatives'                                           => 'Milk Alternatives',
			'Mining & Metals'                                             => 'Mining & Metals',
			'Mobile'                                                      => 'Mobile',
			'Mobile Apps'                                                 => 'Mobile Apps',
			'Monitoring'                                                  => 'Monitoring',
			'Movers'                                                      => 'Movers',
			'Movies & Film'                                               => 'Movies & Film',
			'Museums & Institutions'                                      => 'Museums & Institutions',
			'Music'                                                       => 'Music',
			'Nail Products'                                               => 'Nail Products',
			'NanoTech'                                                    => 'NanoTech',
			'Network Infrastructure'                                      => 'Network Infrastructure',
			'News'                                                        => 'News',
			'Newspapers'                                                  => 'Newspapers',
			'No Code'                                                     => 'No Code',
			'Nonprofit Management'                                        => 'Nonprofit Management',
			'Oil & Gas'                                                   => 'Oil & Gas',
			'Open Source Software'                                        => 'Open Source Software',
			'OSS'                                                         => 'OSS',
			'Outsourcing & Offshoring'                                    => 'Outsourcing & Offshoring',
			'PaaS'                                                        => 'PaaS',
			'Packaging'                                                   => 'Packaging',
			'Paper Products'                                              => 'Paper Products',
			'Payments'                                                    => 'Payments',
			'Performance Marketing'                                       => 'Performance Marketing',
			'Performing Arts'                                             => 'Performing Arts',
			'Personal Care Products'                                      => 'Personal Care Products',
			'Personal Cleansing Products'                                 => 'Personal Cleansing Products',
			'Pets'                                                        => 'Pets',
			'Pharmaceuticals'                                             => 'Pharmaceuticals',
			'Philanthropy'                                                => 'Philanthropy',
			'Photography'                                                 => 'Photography',
			'Physical Security'                                           => 'Physical Security',
			'Physical Storage'                                            => 'Physical Storage',
			'Plastics'                                                    => 'Plastics',
			'Platform-as-a-Service'                                       => 'Platform-as-a-Service',
			'Political Organization'                                      => 'Political Organization',
			'Primary & Secondary Education'                               => 'Primary & Secondary Education',
			'Printing'                                                    => 'Printing',
			'Private Equity'                                              => 'Private Equity',
			'Procurement'                                                 => 'Procurement',
			'Professional Training & Coaching'                            => 'Professional Training & Coaching',
			'Project Management'                                          => 'Project Management',
			'Public Policy'                                               => 'Public Policy',
			'Public Relations'                                            => 'Public Relations',
			'Public Safety'                                               => 'Public Safety',
			'Publishing'                                                  => 'Publishing',
			'QA'                                                          => 'QA',
			'Quality Assurance'                                           => 'Quality Assurance',
			'Ranching'                                                    => 'Ranching',
			'Real Estate'                                                 => 'Real Estate',
			'Recreational Facilities & Services'                          => 'Recreational Facilities & Services',
			'Recruiting & Staffing'                                       => 'Recruiting & Staffing',
			'Recruitment'                                                 => 'Recruitment',
			'Religion & Spirituality'                                     => 'Religion & Spirituality',
			'Renewables'                                                  => 'Renewables',
			'Renewables'                                                  => 'Renewables',
			'Research'                                                    => 'Research',
			'Restaurants'                                                 => 'Restaurants',
			'Retail'                                                      => 'Retail',
			'RetailTech'                                                  => 'RetailTech',
			'Reviews'                                                     => 'Reviews',
			'Rewards & Loyalty'                                           => 'Rewards & Loyalty',
			'Robotics'                                                    => 'Robotics',
			'SaaS'                                                        => 'SaaS',
			'Sales'                                                       => 'Sales',
			'SalesTech'                                                   => 'SalesTech',
			'Scents and Perfumes'                                         => 'Scents and Perfumes',
			'Science'                                                     => 'Science',
			'Scraping'                                                    => 'Scraping',
			'Security'                                                    => 'Security',
			'Self Storage'                                                => 'Self Storage',
			'SEM'                                                         => 'SEM',
			'Semiconductors'                                              => 'Semiconductors',
			'SEO'                                                         => 'SEO',
			'Services'                                                    => 'Services',
			'Services, Law & Politics'                                    => 'Services, Law & Politics',
			'Shaving & Beard Care'                                        => 'Shaving & Beard Care',
			'Shipbuilding'                                                => 'Shipbuilding',
			'Shipping & Delivery'                                         => 'Shipping & Delivery',
			'Skincare Products'                                           => 'Skincare Products',
			'SMS Marketing'                                               => 'SMS Marketing',
			'Social Media Marketing'                                      => 'Social Media Marketing',
			'Software'                                                    => 'Software',
			'Software Development'                                        => 'Software Development',
			'Software-as-a-Service'                                       => 'Software-as-a-Service',
			'Solar Energy'                                                => 'Solar Energy',
			'Specifically book-related libraries, not software libraries' => 'Specifically book-related libraries, not software libraries',
			'Sporting Goods'                                              => 'Sporting Goods',
			'Sports'                                                      => 'Sports',
			'Startups'                                                    => 'Startups',
			'Streaming'                                                   => 'Streaming',
			'Suncare Products'                                            => 'Suncare Products',
			'Supermarkets'                                                => 'Supermarkets',
			'Support'                                                     => 'Support',
			'Synthetic Biology'                                           => 'Synthetic Biology',
			'Tablets'                                                     => 'Tablets',
			'Talent Management'                                           => 'Talent Management',
			'Tattoo & Piercing'                                           => 'Tattoo & Piercing',
			'Technology & Computing'                                      => 'Technology & Computing',
			'Telecommunications'                                          => 'Telecommunications',
			'Textiles'                                                    => 'Textiles',
			'Think Tanks'                                                 => 'Think Tanks',
			'Tobacco'                                                     => 'Tobacco',
			'Translation & Localization'                                  => 'Translation & Localization',
			'Transportation'                                              => 'Transportation',
			'Travel & Tourism'                                            => 'Travel & Tourism',
			'Trucking & Railroad'                                         => 'Trucking & Railroad',
			'Tutoring'                                                    => 'Tutoring',
			'Twitter-Related'                                             => 'Twitter-Related',
			'User Experience'                                             => 'User Experience',
			'Utilities'                                                   => 'Utilities',
			'UX'                                                          => 'UX',
			'Vaping'                                                      => 'Vaping',
			'Vegetarian & Vegan'                                          => 'Vegetarian & Vegan',
			'Venture Capital'                                             => 'Venture Capital',
			'Veterinary'                                                  => 'Veterinary',
			'Vices'                                                       => 'Vices',
			'Video Game Development'                                      => 'Video Game Development',
			'Videos'                                                      => 'Videos',
			'Vintage & Antique Goods'                                     => 'Vintage & Antique Goods',
			'Voice over Internet Protocol'                                => 'Voice over Internet Protocol',
			'VoIP'                                                        => 'VoIP',
			'Warehousing'                                                 => 'Warehousing',
			'Waste Management'                                            => 'Waste Management',
			'Web Applications'                                            => 'Web Applications',
			'Web Design'                                                  => 'Web Design',
			'Web Development'                                             => 'Web Development',
			'Web Optimization'                                            => 'Web Optimization',
			'WebApp'                                                      => 'WebApp',
			'Weddings'                                                    => 'Weddings',
			'Weight Loss'                                                 => 'Weight Loss',
			'Wholesaling'                                                 => 'Wholesaling',
			'Wind Energy'                                                 => 'Wind Energy',
			'Wine & Spirits'                                              => 'Wine & Spirits',
			'Work Uniforms'                                               => 'Work Uniforms',
			'Writing & Editing'                                           => 'Writing & Editing',
			'Youtube-Related'                                             => 'Youtube-Related',
		);

		foreach ( $categories as $raw_category => $label ) {
			$categories[ $raw_category ] = $label;
		}
		return $categories;
	}

	/**
	 * Get the job types.
	 *
	 * @return array
	 */
	public static function job_types() {
		return array(
			'Full-Time'   => 'Full-Time',
			'Part-Time'   => 'Part-Time',
			'Contract'    => 'Contract',
			'Volunteer'   => 'Volunteer',
			'Hourly'      => 'Hourly',
			'Gig'         => 'Gig',
			'Commission'  => 'Commission',
			'Trainee'     => 'Trainee',
			'Intern'      => 'Intern',
			'Temp'        => 'Temp',
			'Grant'       => 'Grant',
			'Conditional' => 'Conditional',
			'Student'     => 'Student',
		);
	}

	/**
	 * Get the job education.
	 *
	 * @return array
	 */
	public static function job_education() {
		return array(
			'Doctorate'                => 'Doctorate',
			'Masters'                  => 'Masters',
			'Bachelors'                => 'Bachelors',
			'Associates'               => 'Associates',
			'Some College'             => 'Some College',
			'Vocational'               => 'Vocational',
			'Certification'            => 'Certification',
			'High School'              => 'High School',
			'Some High School'         => 'Some High School',
			'No Education Requirement' => 'No Education Requirement',
		);
	}


	/**
	 * FRONTEND
	 */


	/**
	 * Block robots if option is enabled.
	 */
	public function maybe_no_robots( $robots, $feed ) {
		global $goft_wpjm_options;

		if ( ! $this->condition() ) {
			return $robots;
		}

		if ( $goft_wpjm_options->adzuna_block_search_indexing ) {
			$robots['noindex'] = true;
		}
		return $robots;
	}


}
new GoFetch_sourcestack_API_Feed_Provider();
