<?php
/* THIS IS A GENERATED FILE. DO NOT EDIT DIRECTLY. */
$generated_i18n_strings = array(
	// Reference: ../../../packages/js/components/ConfirmDialog.tsx:58
	__( 'No', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/components/ConfirmDialog.tsx:61
	__( 'Yes', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/components/InstructionsLink.tsx:14
	__( 'Click here for instructions.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/components/instructions/Instructions.tsx:20
	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtons.tsx:46
	__( 'INSTRUCTIONS!', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/components/plugin-info/PluginInfoCard.tsx:61
	/* translators: %s: plugin name */
	__( 'Do you like %s?', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/components/plugin-info/PluginInfoCard.tsx:75
	__( 'Write a review', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/components/plugin-info/PluginInfoCard.tsx:89
	__( 'Need help?', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/components/widget-info/WidgetInfo.tsx:31
	/* translators: 1, 2 Menu names */
	__( 'Goto %1$s and click/drag %2$s and place it where you want it to be.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/components/widget-info/WidgetInfo.tsx:40
	__( 'Appearance', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/components/widget-info/WidgetInfo.tsx:41
	__( 'Widgets', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/components/widget-info/WidgetInfo.tsx:49
	__( 'Alternately, you can use the below shortcode or the block available in block editor.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/components/widget-info/WidgetInfo.tsx:53
	__( 'Inside page or post content:', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/components/widget-info/WidgetInfo.tsx:57
	__( 'Inside the theme templates', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/components/widget-info/WidgetInfo.tsx:61
	__( 'or', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/components/widget-info/WidgetInfoCard.tsx:16
	__( 'Widget Info', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/components/wptg-social-icons/WPTGSocialIcons.tsx:50
	/* translators: %s: social handle */
	__( 'Follow %s', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/components/wptg-social-icons/WPTGSocialIcons.tsx:66
	/* translators: %s: channel name */
	__( 'Join %s', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/form-components/BotTokenField.tsx:43
	// Reference: js/settings/ui/bots/useBotFields.tsx:55
	__( 'Please read the instructions above.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/form-components/submit/SubmitButton.tsx:15
	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGInstructions.tsx:111
	// Reference: js/p2tg-block-editor/OverrideSettings.tsx:76
	__( 'Save Changes', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/form-components/test-result/MemberCountResult.tsx:18
	__( 'Members Count:', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/form-components/test-result/MessageResult.tsx:18
	// Reference: js/p2tg-instant-post/ui/Footer.tsx:17
	__( 'Result:', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/form-components/test-result/TestResult.tsx:17
	__( 'Test Result:', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/form-components/useBotTokenTest.tsx:111
	// Reference: ../../../packages/js/form-components/useChatWithTest.tsx:110
	// Reference: js/settings/ui/advanced/licence/Modal.tsx:80
	// Reference: js/settings/ui/bots/WebhookInfo.tsx:150
	// Reference: js/settings/ui/importSettings/ImportSettings.tsx:43
	__( 'Please wait…', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/form-components/useBotTokenTest.tsx:112
	// Reference: js/settings/ui/bots/useBotFields.tsx:64
	__( 'Test Token', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/form-components/useChatWithTest.tsx:111
	__( 'Send Test', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/form/render/RenderRepeatable.tsx:122
	// Reference: ../../../packages/js/shared/wptelegram-ui/components/rules/AddRuleGroup.tsx:19
	// Reference: ../../../packages/js/shared/wptelegram-ui/components/rules/RuleSetButtons.tsx:30
	// Reference: js/instant-messages/ui/ChatIdInput.tsx:66
	__( 'Add', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/services/apiFetch/index.ts:36
	__( 'Something went wrong', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/services/apiFetch/index.ts:38
	// Reference: js/settings/ui/advanced/licence/useLicenceInfo.ts:81
	__( 'Could not connect', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/services/apiFetch/index.ts:41
	__( 'Error:', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/services/telegram/TelegramUtils.ts:125
	__( 'A message will be sent to the Channel/Group/Chat. You can modify the text below', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/services/telegram/TelegramUtils.ts:128
	__( 'This is a test message', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/services/telegram/TelegramUtils.ts:150
	// Reference: js/instant-messages/services/useSubmitForm.ts:64
	__( 'Success', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/services/useDisplayFeedback.ts:65
	__( 'Lets fix these errors first.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/services/useSubmitForm.ts:63
	__( 'Changes saved successfully.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/AdvancedSettings.tsx:36
	__( 'View log', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/AdvancedSettings.tsx:47
	__( 'Settings in this section should not be changed unless recommended by WP Telegram Support.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/AdvancedSettings.tsx:55
	__( 'Turn off to upload the files/images instead of passing the url.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/DelayInPosting.tsx:22
	__( 'The delay starts after the post gets published.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/DelayInPosting.tsx:25
	__( 'Minute(s)', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/DelayInPosting.tsx:30
	__( 'WordPress cron should not be disabled!', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/DisableNotification.tsx:13
	__( 'Send the messages silently.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/DisableNotification.tsx:14
	__( 'Users will receive a notification with no sound.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/ExcerptSettings.tsx:12
	__( 'Post Content', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/ExcerptSettings.tsx:16
	__( 'Before "Read More"', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/ExcerptSettings.tsx:20
	__( 'Post Excerpt', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/ExcerptSettings.tsx:46
	__( 'Number of words for the excerpt.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/ExcerptSettings.tsx:60
	__( 'Preserve newlines in Post Excerpt.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/ImageSettings.tsx:21
	__( 'Before the Text', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/ImageSettings.tsx:26
	// Reference: ../../../packages/js/shared/wptelegram-ui/components/SingleMessage.tsx:54
	__( 'After the Text', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/ImageSettings.tsx:37
	// Reference: js/p2tg-block-editor/components/Instance.tsx:61
	__( 'Send Featured Image (if exists).', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/KeyboardButton.tsx:76
	__( 'Edit button', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/KeyboardButton.tsx:83
	__( 'Copy button', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/KeyboardButton.tsx:90
	__( 'Delete button', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/LinkPreviewOptions.tsx:21
	__( 'Disables previews for links in the messages.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/LinkPreviewOptions.tsx:33
	__( 'URL to use for the link preview.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/LinkPreviewOptions.tsx:38
	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGInstructions.tsx:154
	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtons.tsx:212
	__( 'For example %s', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/LinkPreviewOptions.tsx:57
	__( 'Whether the link preview must be shown above the message text.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/MessageTemplate.tsx:19
	__( 'Structure of the message to be sent.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/MiscMessageSettings.tsx:19
	__( 'Send categories as hashtags.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/MiscMessageSettings.tsx:35
	// Reference: ../../../packages/js/shared/wptelegram-ui/components/ParseModeField.tsx:42
	// Reference: ../../../packages/js/shared/wptelegram-ui/components/TemplateInfo.tsx:39
	// Reference: js/p2tg-instance-editor/ui/additionalMedia/AdditionalMedia.tsx:33
	__( 'Learn more', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/MiscMessageSettings.tsx:38
	__( 'Protects the contents of sent messages from forwarding and saving.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/NotifyInstructions.tsx:114
	// Reference: js/settings/ui/TabbedSections.tsx:28
	__( 'Private Notifications', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/NotifyInstructions.tsx:27
	__( 'To receive notifications privately:', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/NotifyInstructions.tsx:33
	/* translators: 1 bot username */
	__( 'Get your Chat ID from %s and enter it below.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/NotifyInstructions.tsx:49
	/* translators: 1 bot username */
	__( 'Send your own bot %s a message to start the conversation.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/NotifyInstructions.tsx:66
	__( 'To receive notifications into a group:', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/NotifyInstructions.tsx:72
	/* translators: 1 bot username */
	__( 'Add %s to the group to get its Chat ID.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/NotifyInstructions.tsx:84
	/* translators: 1 field name */
	__( 'Enter the Chat ID in %s field below.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/NotifyInstructions.tsx:88
	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:21
	// Reference: js/settings/services/fields.ts:25
	__( 'Send it to', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/NotifyInstructions.tsx:96
	/* translators: 1 bot username */
	__( 'Add your own bot %s to the group.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/NotifyMessageTemplate.tsx:15
	// Reference: ../../../packages/js/shared/wptelegram-ui/components/TemplateInfo.tsx:31
	__( 'You can use any text, emojis or these macros in any order.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGInstructions.tsx:107
	/* translators: %s button name */
	__( 'Hit %s below.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGInstructions.tsx:119
	// Reference: js/settings/ui/shared/IntroVideo.tsx:6
	__( 'Introduction', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGInstructions.tsx:128
	__( 'Tip!', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGInstructions.tsx:133
	__( 'You can add an internal note to the chat ID to make it easier for you to identify it.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGInstructions.tsx:142
	/* translators: %s pipe character */
	__( 'Note can be added after %s.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGInstructions.tsx:26
	__( 'Create a Telegram channel or group.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGInstructions.tsx:31
	/* translators: %s bot username */
	__( 'Add your bot %s as Administrator to your Channel/Group.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGInstructions.tsx:44
	__( 'Enter the Channel Username in the field below.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGInstructions.tsx:51
	/* translators: %s symbol - @ */
	__( 'Username must start with %s', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGInstructions.tsx:60
	__( 'You can also use the Chat ID of a group or private chat.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGInstructions.tsx:65
	/* translators: %s bot username */
	__( 'Get it from %s.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGInstructions.tsx:81
	/* translators: %s colon character */
	__( 'If you want to send posts to a specific topic in a group with topics enabled, you can add a colon (%s) to the chat ID followed by topic ID.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGSwitchAndPluginPosts.tsx:13
	__( 'Show an ON/OFF switch on the post edit screen.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGSwitchAndPluginPosts.tsx:14
	__( 'You can use this switch to override the settings for a particular post.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/P2TGSwitchAndPluginPosts.tsx:23
	__( 'Enable this option if you use a plugin to generate posts.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/ParseModeField.tsx:17
	// Reference: ../../../packages/js/shared/wptelegram-ui/components/SingleMessage.tsx:70
	// Reference: js/p2tg-instance-editor/ui/messageKeyboard/MessageKeyboard.tsx:32
	// Reference: js/settings/ui/bots/useBotFields.tsx:85
	__( 'None', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/ParseModeField.tsx:21
	__( 'HTML style', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/SingleMessage.tsx:34
	__( 'Send both text and image in single message.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/SingleMessage.tsx:48
	/* translators: 1 - field name, 2 - value */
	__( 'When %1$s is set to %2$s:', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/SingleMessage.tsx:64
	/* translators: 1 - field name, 2 - value */
	__( '%1$s should not be %2$s.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/SingleMessage.tsx:80
	/* translators: 1 - field name */
	__( '%s should not be enabled.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/TemplateInfo.tsx:36
	__( 'You can also use conditional logic in the template.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/UserNotifications.tsx:20
	__( 'Allow users receive their email notifications on Telegram.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/UserNotifications.tsx:31
	/* translators: 1 Plugin name */
	__( 'Use %s to let them connect their Telegram account.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/UserNotifications.tsx:49
	/* translators: 1 profile page */
	__( 'They can also enter their Telegram Chat ID manually on %s page.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/UserNotifications.tsx:57
	__( 'profile', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/CFWorker.tsx:14
	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/GoogleScript.tsx:16
	__( 'The requests to Telegram will be sent via this URL.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/PHPProxy.tsx:11
	__( 'HTTP', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/PHPProxy.tsx:15
	__( 'SOCKS4', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/PHPProxy.tsx:19
	__( 'SOCKS4A', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/PHPProxy.tsx:23
	__( 'SOCKS5', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/PHPProxy.tsx:27
	__( 'SOCKS5_HOSTNAME', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/PHPProxy.tsx:39
	/* translators: IP address */
	__( 'Host IP or domain name like %s.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/PHPProxy.tsx:51
	/* translators: proxy port */
	__( 'Target Port like %s.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/PHPProxy.tsx:76
	__( 'Leave empty if not required.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/Proxy.tsx:16
	__( 'Cloudflare worker', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/Proxy.tsx:20
	__( 'Google Script', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/Proxy.tsx:24
	__( 'PHP Proxy', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/Proxy.tsx:34
	__( 'The module will help you bypass the ban on Telegram by making use of proxy.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/Proxy.tsx:41
	// Reference: js/settings/ui/TabbedSections.tsx:33
	__( 'Proxy', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/Proxy.tsx:48
	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:42
	__( 'Proxy Method', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/Proxy.tsx:53
	__( 'Cloudflare worker is preferred.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/ProxyDisclaimer.tsx:11
	__( 'Use the proxy at your own risk!', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/ProxyDisclaimer.tsx:8
	__( 'DISCLAIMER!', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/proxy/ProxySettings.tsx:17
	__( 'Proxy settings', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/rules/And.tsx:8
	__( 'AND', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/rules/Or.tsx:8
	// Reference: js/instant-messages/ui/ChatIdInput.tsx:74
	// Reference: js/instant-messages/ui/SelectUsers.tsx:89
	__( 'OR', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/rules/P2TGCustomRules.tsx:51
	__( 'You can also define custom rules to send the posts.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/rules/RuleSetButtons.tsx:39
	// Reference: js/p2tg-instance-editor/ui/additionalMedia/SingleMedia.tsx:39
	__( 'Remove', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/rules/RuleSetFields.tsx:11
	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:47
	__( 'is in', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/rules/RuleSetFields.tsx:15
	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:51
	__( 'is not in', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/rules/RuleSetFields.tsx:27
	// Reference: js/p2tg-instance-editor/ui/rules/CustomRuleSetFields.tsx:16
	__( 'Rule type', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/rules/RuleSetFields.tsx:35
	// Reference: js/p2tg-instance-editor/ui/rules/CustomRuleSetFields.tsx:32
	__( 'Rule operator', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/rules/RuleSetValues.tsx:103
	__( 'Select...', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/rules/RuleSetValues.tsx:16
	// Reference: js/instant-messages/ui/SelectP2tgChannels.tsx:16
	// Reference: js/instant-messages/ui/SelectUsers.tsx:16
	__( 'Loading...', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/rules/RuleSetValues.tsx:17
	// Reference: js/instant-messages/ui/SelectP2tgChannels.tsx:17
	// Reference: js/instant-messages/ui/SelectUsers.tsx:17
	__( 'No options available', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/components/rules/RuleSetValues.tsx:91
	__( 'Rule values', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:13
	__( 'Active', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:14
	__( 'Bot', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:15
	__( 'Bot Token', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:16
	__( 'Bot Username', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:17
	__( 'Categories as hashtags', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:18
	__( 'Cloudflare worker URL', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:19
	// Reference: js/settings/services/fields.ts:20
	__( 'Channel(s)', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:20
	// Reference: js/settings/services/fields.ts:21
	__( 'Chat ID', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:22
	__( 'Remove settings on uninstall', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:23
	__( 'Debug Info', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:24
	// Reference: js/p2tg-block-editor/components/Instance.tsx:49
	__( 'Delay in Posting', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:25
	// Reference: js/p2tg-block-editor/components/Instance.tsx:43
	__( 'Disable Notifications', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:26
	__( 'Disable link preview', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:27
	__( 'Link preview URL', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:28
	__( 'Show preview above text', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:29
	__( 'Enable logs for', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:30
	__( 'Excerpt Length', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:31
	__( 'Excerpt Newlines', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:32
	__( 'Excerpt Source', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:33
	__( 'Google Script URL', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:34
	__( 'Image Position', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:35
	// Reference: js/p2tg-block-editor/components/Instance.tsx:65
	__( 'Message Template', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:36
	// Reference: js/instant-messages/services/fields.ts:9
	__( 'Formatting', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:37
	__( 'Plugin generated posts', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:38
	__( 'Post edit switch', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:39
	__( 'Post type', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:40
	__( 'Protect content', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:41
	__( 'Proxy Host', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:43
	__( 'Password', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:44
	__( 'Proxy Port', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:45
	__( 'Proxy Type', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:46
	__( 'Username', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:47
	// Reference: js/p2tg-block-editor/components/Instance.tsx:58
	__( 'Featured Image', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:48
	__( 'Send files by URL', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:49
	__( 'Single message', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/shared/wptelegram-ui/services/fields.ts:50
	__( 'Notifications to Users', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/utilities/fields.ts:35
	/* translators: %s: field label */
	__( 'Invalid %s', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/utilities/fields.ts:39
	/* translators: %s: field label */
	__( '%s required.', 'wptelegram-pro' ),

	// Reference: ../../../packages/js/utilities/fields.ts:42
	__( 'Changes could not be saved.', 'wptelegram-pro' ),

	// Reference: js/instant-messages/services/fields.ts:5
	__( 'Bot to use', 'wptelegram-pro' ),

	// Reference: js/instant-messages/services/fields.ts:6
	// Reference: js/instant-messages/ui/MessageType.tsx:17
	__( 'Text', 'wptelegram-pro' ),

	// Reference: js/instant-messages/services/fields.ts:7
	__( 'Type', 'wptelegram-pro' ),

	// Reference: js/instant-messages/services/fields.ts:8
	__( 'File URL', 'wptelegram-pro' ),

	// Reference: js/instant-messages/ui/ChatIdInput.tsx:60
	__( 'Enter Chat ID or channel username', 'wptelegram-pro' ),

	// Reference: js/instant-messages/ui/ChatIdInput.tsx:71
	__( 'If more than one, separate them by comma', 'wptelegram-pro' ),

	// Reference: js/instant-messages/ui/ChatIdOutput.tsx:32
	__( 'Send to:', 'wptelegram-pro' ),

	// Reference: js/instant-messages/ui/FileURL.tsx:14
	__( 'Select file', 'wptelegram-pro' ),

	// Reference: js/instant-messages/ui/FileURL.tsx:60
	__( 'Select', 'wptelegram-pro' ),

	// Reference: js/instant-messages/ui/MessageType.tsx:13
	// Reference: js/p2tg-instance-editor/ui/additionalMedia/options.ts:12
	__( 'Document', 'wptelegram-pro' ),

	// Reference: js/instant-messages/ui/MessageType.tsx:21
	// Reference: js/p2tg-instance-editor/ui/additionalMedia/options.ts:16
	__( 'Photo', 'wptelegram-pro' ),

	// Reference: js/instant-messages/ui/MessageType.tsx:25
	// Reference: js/p2tg-instance-editor/ui/additionalMedia/options.ts:20
	__( 'Video', 'wptelegram-pro' ),

	// Reference: js/instant-messages/ui/MessageType.tsx:9
	// Reference: js/p2tg-instance-editor/ui/additionalMedia/options.ts:8
	__( 'Audio', 'wptelegram-pro' ),

	// Reference: js/instant-messages/ui/SelectP2tgChannels.tsx:61
	__( 'Select from Post to Telegram...', 'wptelegram-pro' ),

	// Reference: js/instant-messages/ui/SelectUsers.tsx:85
	__( 'Select user...', 'wptelegram-pro' ),

	// Reference: js/instant-messages/ui/SubmitInfo.tsx:30
	// Reference: js/p2tg-instant-post/ui/Footer.tsx:28
	__( 'Send', 'wptelegram-pro' ),

	// Reference: js/instant-messages/ui/SubmitInfo.tsx:37
	__( 'Send message?', 'wptelegram-pro' ),

	// Reference: js/instant-messages/ui/SubmitInfo.tsx:38
	__( 'Are you sure you want to send the message?', 'wptelegram-pro' ),

	// Reference: js/p2tg-block-editor/OverrideSettings.tsx:54
	// Reference: js/settings/ui/TabbedSections.tsx:23
	// Reference: js/settings/ui/advanced/Advanced.tsx:41
	// Reference: js/settings/ui/notify/Notify.tsx:43
	// Reference: js/settings/ui/p2tg/P2TG.tsx:34
	__( 'Post to Telegram', 'wptelegram-pro' ),

	// Reference: js/p2tg-block-editor/OverrideSettings.tsx:62
	__( 'Override settings', 'wptelegram-pro' ),

	// Reference: js/p2tg-block-editor/SendToTelegram.tsx:39
	// Reference: js/p2tg-instant-post/ui/Modal.tsx:47
	__( 'Send to Telegram', 'wptelegram-pro' ),

	// Reference: js/p2tg-block-editor/SendToTelegram.tsx:55
	__( 'Force send', 'wptelegram-pro' ),

	// Reference: js/p2tg-block-editor/SendToTelegram.tsx:57
	// Reference: js/p2tg-instant-post/ui/Settings.tsx:28
	/* translators: %s Rule name */
	__( 'Ignore %s rules.', 'wptelegram-pro' ),

	// Reference: js/p2tg-block-editor/SendToTelegram.tsx:58
	// Reference: js/p2tg-instance-editor/services/fields.ts:27
	// Reference: js/p2tg-instant-post/ui/Settings.tsx:29
	__( 'Use when', 'wptelegram-pro' ),

	// Reference: js/p2tg-block-editor/components/Channels.tsx:43
	__( 'Send to', 'wptelegram-pro' ),

	// Reference: js/p2tg-block-editor/components/Channels.tsx:56
	__( 'Select all', 'wptelegram-pro' ),

	// Reference: js/p2tg-block-editor/components/Files.tsx:18
	__( 'Add or Upload Files', 'wptelegram-pro' ),

	// Reference: js/p2tg-block-editor/components/Files.tsx:58
	__( 'Files to be sent after the message.', 'wptelegram-pro' ),

	// Reference: js/p2tg-block-editor/components/Files.tsx:67
	__( 'Files', 'wptelegram-pro' ),

	// Reference: js/p2tg-block-editor/components/Instances.tsx:77
	// Reference: js/settings/ui/p2tg/Fields.tsx:16
	__( 'Instances', 'wptelegram-pro' ),

	// Reference: js/p2tg-block-editor/components/PanelBodyTitle.tsx:52
	__( 'Use this instance', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/services/fields.ts:134
	__( '%s must be a number.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/services/fields.ts:21
	__( 'Media type', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/services/fields.ts:22
	__( 'WooCommerce product gallery', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/services/fields.ts:24
	__( 'Images from post content', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/services/fields.ts:25
	__( 'Caption', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/services/fields.ts:26
	__( 'Source', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/services/fields.ts:54
	// Reference: js/settings/services/fields.ts:63
	__( 'At least one %s is required.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/services/fields.ts:54
	__( 'channel', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/services/useSaveChanges.ts:79
	__( 'Please add a title.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/Destination.tsx:16
	__( 'Destination', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/Destination.tsx:21
	__( 'Channel Username or Chat ID.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/Instance.tsx:31
	__( 'optional', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/Instance.tsx:32
	__( 'Instance specific bot.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/MessageSettings.tsx:20
	__( 'Message Settings', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/Miscellaneous.tsx:16
	__( 'Miscellaneous', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/Miscellaneous.tsx:19
	// Reference: js/settings/ui/bots/Instructions.tsx:117
	// Reference: js/settings/ui/p2tg/KeyboardButtons/ReactionButtons.tsx:45
	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtons.tsx:225
	__( 'Note:', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/Miscellaneous.tsx:21
	__( 'When using delay, it is recommended to keep a difference of at least one minute between different instances.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/Sidebar.tsx:15
	// Reference: js/settings/ui/Sidebar.tsx:15
	__( 'WP Telegram Pro means Absolute WordPress Telegram integration with premium features.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/Sidebar.tsx:18
	// Reference: js/settings/ui/Sidebar.tsx:18
	__( 'Get LIVE support on Telegram', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/SubmitInfo.tsx:29
	__( 'Trash', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/additionalMedia/AddMedia.tsx:36
	__( 'Add Media Group', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/additionalMedia/AddMedia.tsx:38
	__( 'Add Item', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/additionalMedia/AddMedia.tsx:39
	__( 'Add Media', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/additionalMedia/AdditionalMedia.tsx:24
	__( 'Additional Media', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/additionalMedia/AdditionalMedia.tsx:26
	__( 'In this section, you can attach additional media to your Telegram messages.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/additionalMedia/AdditionalMedia.tsx:37
	__( 'Source can be an absolute URL or a custom field that contains the URL.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/additionalMedia/AdditionalMedia.tsx:42
	__( 'In caption field, you can use anything from message template.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/additionalMedia/AdditionalMedia.tsx:67
	__( 'Whether to send WooCommerce product gallery images.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/additionalMedia/AdditionalMedia.tsx:93
	__( 'Whether to send images from post content.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/additionalMedia/MediaGroup.tsx:30
	__( 'Media group', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/additionalMedia/options.ts:29
	__( 'Animation', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/messageKeyboard/AddRowButton.tsx:15
	__( 'Add Row', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/messageKeyboard/ButtonsPopover.tsx:64
	__( 'Add Button', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/messageKeyboard/MessageKeyboard.tsx:14
	__( 'Message Keyboard', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/messageKeyboard/MessageKeyboard.tsx:18
	__( 'Warning!', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/messageKeyboard/MessageKeyboard.tsx:22
	__( 'Update method of the selected %1$s bot is set to %2$s.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/messageKeyboard/MessageKeyboard.tsx:37
	__( 'Keyboard buttons will not work.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/messageKeyboard/RenderButton.tsx:39
	// Reference: js/settings/ui/p2tg/KeyboardButtons/DisplayButtons.tsx:85
	__( 'Remove button', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/messageKeyboard/RenderPopoverButtons.tsx:28
	__( 'Add button', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/messageKeyboard/RenderRow.tsx:74
	__( 'Remove Row', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/CustomRuleSetFields.tsx:24
	__( 'Custom rule type', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/CustomRuleSetFields.tsx:44
	__( 'Comparison value', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/Rules.tsx:14
	__( 'A new post is published', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/Rules.tsx:18
	__( 'An existing post is updated', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/Rules.tsx:29
	__( 'Rules', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/Rules.tsx:36
	__( 'When the post should be sent to Telegram.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/Rules.tsx:46
	__( 'Which post types should be sent.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:11
	__( 'is not equal', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:15
	__( 'is empty', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:19
	__( 'is not empty', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:23
	__( 'is greater than', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:27
	__( 'is greater than or equal to', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:31
	__( 'is less than', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:35
	__( 'is less than or equal to', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:39
	__( 'contains', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:43
	__( 'does not contain', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:55
	__( 'is between', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:59
	__( 'is not between', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:63
	__( 'starts with', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:67
	__( 'does not start with', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:7
	__( 'is equal to', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:71
	__( 'ends with', 'wptelegram-pro' ),

	// Reference: js/p2tg-instance-editor/ui/rules/operators.ts:75
	__( 'does not end with', 'wptelegram-pro' ),

	// Reference: js/p2tg-instant-post/ui/Footer.tsx:18
	__( 'There was some error.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instant-post/ui/Footer.tsx:18
	// Reference: js/settings/ui/p2tg/KeyboardButtons/ReactionButtonsInput.tsx:114
	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtonsInput.tsx:91
	__( 'Done', 'wptelegram-pro' ),

	// Reference: js/p2tg-instant-post/ui/Footer.tsx:31
	__( 'Cancel', 'wptelegram-pro' ),

	// Reference: js/p2tg-instant-post/ui/Settings.tsx:25
	__( 'Settings', 'wptelegram-pro' ),

	// Reference: js/p2tg-instant-post/ui/Settings.tsx:37
	__( 'Ignore all rules.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instant-post/ui/Settings.tsx:42
	__( 'Send instantly without delay.', 'wptelegram-pro' ),

	// Reference: js/p2tg-instant-post/ui/index.tsx:54
	__( 'Please select a post to send.', 'wptelegram-pro' ),

	// Reference: js/settings/services/fields.ts:22
	__( 'If Email goes to', 'wptelegram-pro' ),

	// Reference: js/settings/services/fields.ts:23
	__( 'Licence key', 'wptelegram-pro' ),

	// Reference: js/settings/services/fields.ts:24
	__( 'Send attachments', 'wptelegram-pro' ),

	// Reference: js/settings/services/fields.ts:26
	__( 'Update method', 'wptelegram-pro' ),

	// Reference: js/settings/services/fields.ts:63
	__( 'bot', 'wptelegram-pro' ),

	// Reference: js/settings/services/useImportSettings.ts:30
	__( 'Settings imported successfully', 'wptelegram-pro' ),

	// Reference: js/settings/services/useImportSettings.ts:34
	__( 'Error importing settings', 'wptelegram-pro' ),

	// Reference: js/settings/services/utils.ts:54
	__( 'Your license key expired on %s.', 'wptelegram-pro' ),

	// Reference: js/settings/services/utils.ts:60
	__( 'Your license key has been disabled.', 'wptelegram-pro' ),

	// Reference: js/settings/services/utils.ts:64
	__( 'Invalid license key.', 'wptelegram-pro' ),

	// Reference: js/settings/services/utils.ts:67
	__( 'Your license is not active for this website.', 'wptelegram-pro' ),

	// Reference: js/settings/services/utils.ts:70
	__( 'This appears to be an invalid license key for this product.', 'wptelegram-pro' ),

	// Reference: js/settings/services/utils.ts:75
	__( 'Your license key has reached its activation limit.', 'wptelegram-pro' ),

	// Reference: js/settings/services/utils.ts:78
	__( 'An error occurred, please try again.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/TabbedSections.tsx:18
	__( 'Bots', 'wptelegram-pro' ),

	// Reference: js/settings/ui/TabbedSections.tsx:38
	__( 'Advanced settings', 'wptelegram-pro' ),

	// Reference: js/settings/ui/advanced/Advanced.tsx:30
	__( '(Outgoing Requests)', 'wptelegram-pro' ),

	// Reference: js/settings/ui/advanced/Advanced.tsx:36
	__( 'Bot API', 'wptelegram-pro' ),

	// Reference: js/settings/ui/advanced/Advanced.tsx:36
	__( '(Incoming Requests)', 'wptelegram-pro' ),

	// Reference: js/settings/ui/advanced/licence/ActivationResult.tsx:31
	__( 'License key has been activated successfully.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/advanced/licence/ActivationResult.tsx:31
	__( 'Don\'t forget to save the changes.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/advanced/licence/Licence.tsx:54
	__( 'Lets activate the licence.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/advanced/licence/Licence.tsx:57
	__( 'There seems to be some issue with your licence.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/advanced/licence/Licence.tsx:60
	__( 'Manage your licence.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/advanced/licence/Licence.tsx:66
	__( 'Edit licence', 'wptelegram-pro' ),

	// Reference: js/settings/ui/advanced/licence/Modal.tsx:108
	__( 'Please goto %s page to find the licence key.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/advanced/licence/Modal.tsx:109
	__( 'My Account', 'wptelegram-pro' ),

	// Reference: js/settings/ui/advanced/licence/Modal.tsx:113
	__( 'Or', 'wptelegram-pro' ),

	// Reference: js/settings/ui/advanced/licence/Modal.tsx:119
	__( 'Click here', 'wptelegram-pro' ),

	// Reference: js/settings/ui/advanced/licence/Modal.tsx:134
	__( 'Licence key helps you receive the plugin updates automatically.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/advanced/licence/Modal.tsx:80
	__( 'Activate', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/Bots.tsx:49
	__( 'Add Bot', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/Instructions.tsx:102
	__( 'New Updates will be PULLED from Telegram on a regular interval.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/Instructions.tsx:122
	/* translators: Update method - long polling */
	__( 'If you choose %s option, then it is recommended to set up a cron on your hosting server that runs every minute or so, pointing to the below URL.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/Instructions.tsx:125
	// Reference: js/settings/ui/bots/useBotFields.tsx:81
	__( 'Long Polling', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/Instructions.tsx:129
	__( 'Cron URL:', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/Instructions.tsx:22
	/* translators: 1 command name, 2 bot name */
	__( 'Create a Bot by sending %1$s command to %2$s.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/Instructions.tsx:42
	__( 'After completing the steps %s will provide you the Bot Token.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/Instructions.tsx:50
	__( 'Copy the token and paste into the Bot Token field below.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/Instructions.tsx:54
	/* translators: %s application name */
	__( 'For ease, use %s', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/Instructions.tsx:60
	__( 'Telegram Desktop', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/Instructions.tsx:67
	__( 'Test your bot token below and fill in the bot username if not filled automatically.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/Instructions.tsx:72
	__( 'If you want to process incoming updates like Post Telegram reaction buttons, select an appropriate update method.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/Instructions.tsx:83
	// Reference: js/settings/ui/bots/useBotFields.tsx:74
	__( 'Webhook', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/Instructions.tsx:87
	__( 'New Updates will be PUSHED to your website in realtime on a secure URL.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/WebhookInfo.tsx:109
	__( 'Webhook Info', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/WebhookInfo.tsx:118
	__( 'Get Info', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/WebhookInfo.tsx:140
	__( 'Action', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/WebhookInfo.tsx:32
	__( 'Please make sure Webhook is set.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/WebhookInfo.tsx:47
	__( 'Delete Webhook', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/WebhookInfo.tsx:47
	__( 'Set Webhook', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/WebhookInfo.tsx:55
	__( 'Webhook is set.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/WebhookInfo.tsx:58
	__( 'Webhook is not set.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/useBotFields.tsx:63
	__( 'Use %s to set automatically.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/useBotFields.tsx:75
	__( 'Recommended', 'wptelegram-pro' ),

	// Reference: js/settings/ui/bots/useBotFields.tsx:75
	__( 'Requires SSL', 'wptelegram-pro' ),

	// Reference: js/settings/ui/importSettings/ImportSettings.tsx:33
	__( 'Do you want to import settings from WP Telegram (free version)?', 'wptelegram-pro' ),

	// Reference: js/settings/ui/importSettings/ImportSettings.tsx:43
	__( 'Import settings', 'wptelegram-pro' ),

	// Reference: js/settings/ui/importSettings/ImportSettings.tsx:47
	__( 'You seem to be on an older version of WP Telegram (free version). Please update it to the latest version, then import the settings.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/importSettings/ImportSettings.tsx:53
	__( 'Make sure that it is active when updating.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/importSettings/ImportSettings.tsx:60
	__( 'You can deactivate the free version after importing settings.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/notify/CatchEmails.tsx:24
	__( 'Entries', 'wptelegram-pro' ),

	// Reference: js/settings/ui/notify/Notify.tsx:28
	__( 'The module will watch the Email Notifications sent from this site and deliver them to you on Telegram.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/notify/Notify.tsx:42
	// Reference: js/settings/ui/p2tg/P2TG.tsx:33
	/* translators: %s is module name */
	__( 'Default bot for %s module.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/notify/Notify.tsx:54
	__( 'Email to Telegram', 'wptelegram-pro' ),

	// Reference: js/settings/ui/notify/Notify.tsx:56
	__( 'Any email notification that goes to the below entered email addresses will be sent to the corresponding chat on Telegram.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/notify/Notify.tsx:74
	__( 'Forward email attachments along with text.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/notify/useCatchEmailsFields.tsx:45
	__( 'Telegram User or Group Chat ID.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/Fields.tsx:19
	__( 'Please save changes and reload the page.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/Fields.tsx:22
	__( 'Click here to create, view or edit the instances.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/KeyboardButtons.tsx:24
	__( 'Inline Keyboard Buttons', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/KeyboardButtons.tsx:25
	__( 'Here you can add your own custom buttons.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/ReactionButtons.tsx:28
	__( 'Reaction Buttons', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/ReactionButtons.tsx:48
	__( 'Button name should be unique and contain only a maximum of 8 English letters or underscore.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/ReactionButtonsInput.tsx:21
	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtonsInput.tsx:15
	__( 'Label', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtons.tsx:109
	__( 'You can also create a direct login button which will send the user to your website and log them in via Telegram.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtons.tsx:117
	__( 'More details here.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtons.tsx:122
	__( 'Use %1$s or %2$s in the URL field and anything in the Label field.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtons.tsx:176
	__( 'If you have a Telegram <a>Mini App</a>, you can send it as such by adding %s as the URL query parameter.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtons.tsx:201
	__( 'If you wish the user to be logged in to your Mini App, you can add %s as the URL query parameter.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtons.tsx:231
	__( 'This feature needs %s plugin to be active and setup using the same bot token.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtons.tsx:249
	__( 'Warning:', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtons.tsx:252
	__( 'Mini Apps are available only in private chats between a user and the bot.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtons.tsx:256
	__( 'Using Mini App buttons for channels or groups will result in failure to send messages.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtons.tsx:30
	__( 'URL Buttons', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtons.tsx:50
	__( 'In URL field, you can set an absolute URL or a dynamic one using the custom field tags as in Message Template.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/KeyboardButtons/UrlButtons.tsx:76
	__( 'If you add the tags as URL query parameters, make sure you wrap them in %s.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/p2tg/P2TG.tsx:18
	__( 'With this module, you can configure how the posts are sent to Telegram.', 'wptelegram-pro' ),

	// Reference: js/settings/ui/shared/IfBot.tsx:21
	__( 'You must choose a bot for the module.', 'wptelegram-pro' )
);
/* THIS IS THE END OF THE GENERATED FILE */
