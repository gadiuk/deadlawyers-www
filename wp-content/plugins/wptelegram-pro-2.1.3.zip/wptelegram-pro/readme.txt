=== WP Telegram Pro ===
Contributors: wpsocio, irshadahmad21
Donate link: https://wptelegram.pro
Tags: telegram, notifications, posts, channel, group
Requires at least: 6.2
Requires PHP: 7.4
Tested up to: 6.4.3
Stable tag: 2.1.3

Integrate your WordPress site perfectly with Telegram with full control.

== Description ==
Integrate your WordPress site perfectly with Telegram with full control.

Visit [wptelegram.pro](https://wptelegram.pro) for more details.

== Changelog ==

= 2.1.3 =
- Fixed update handler action hook conflict
- Fixed webhook URL not set correctly
- Improved logging for HTML conversion errors for private notifications
- Fixed message failure when inline button URL is empty

[See full changelog](https://wpsocio.com/wptelegram-pro)
