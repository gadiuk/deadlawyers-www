# Changelog

## 2.1.3

### Patch Changes

- [#91](https://github.com/wpsocio/wp-premium-projects/pull/91) [`daeeeb6`](https://github.com/wpsocio/wp-premium-projects/commit/daeeeb687a92709f04ada31f5781fd073e0c25f5) Thanks [@irshadahmad21](https://github.com/irshadahmad21)! - Fixed update handler action hook conflict

- [#91](https://github.com/wpsocio/wp-premium-projects/pull/91) [`daeeeb6`](https://github.com/wpsocio/wp-premium-projects/commit/daeeeb687a92709f04ada31f5781fd073e0c25f5) Thanks [@irshadahmad21](https://github.com/irshadahmad21)! - Fixed webhook URL not set correctly

- [#88](https://github.com/wpsocio/wp-premium-projects/pull/88) [`6bffd8c`](https://github.com/wpsocio/wp-premium-projects/commit/6bffd8c4eb217c553c792b8552dd363889665980) Thanks [@irshadahmad21](https://github.com/irshadahmad21)! - Improved logging for HTML conversion errors for private notifications

- [#90](https://github.com/wpsocio/wp-premium-projects/pull/90) [`43aa6b2`](https://github.com/wpsocio/wp-premium-projects/commit/43aa6b27fad5757c86706eefd75eb40fad57e07c) Thanks [@irshadahmad21](https://github.com/irshadahmad21)! - Fixed message failure when inline button URL is empty

## 2.1.2

### Patch Changes

- [#86](https://github.com/wpsocio/wp-premium-projects/pull/86) [`b6d6773`](https://github.com/wpsocio/wp-premium-projects/commit/b6d6773f3cc0fe6962fe49e2c3b18589f2fd1fb8) Thanks [@irshadahmad21](https://github.com/irshadahmad21)! - Fixed PHP error in logger

## 2.1.1

### Patch Changes

- [#83](https://github.com/wpsocio/wp-premium-projects/pull/83) [`d9115bb`](https://github.com/wpsocio/wp-premium-projects/commit/d9115bb625b005202a24f4b3a05349b3a1dde6a0) Thanks [@irshadahmad21](https://github.com/irshadahmad21)! - Fixed notification attachments not being sent

## 2.1.0

### Minor Changes

- [#78](https://github.com/wpsocio/wp-premium-projects/pull/78) [`44d2122`](https://github.com/wpsocio/wp-premium-projects/commit/44d2122e62ed7830885f73832d217123bea2f19d) Thanks [@irshadahmad21](https://github.com/irshadahmad21)! - Added link preview options

### Patch Changes

- [#77](https://github.com/wpsocio/wp-premium-projects/pull/77) [`e5ec694`](https://github.com/wpsocio/wp-premium-projects/commit/e5ec694f647e7caf068703e7ee4e7d172ffc8f62) Thanks [@irshadahmad21](https://github.com/irshadahmad21)! - Updated German translation

- [#74](https://github.com/wpsocio/wp-premium-projects/pull/74) [`118cb21`](https://github.com/wpsocio/wp-premium-projects/commit/118cb213791b0289de6fdd22e9a4169ea48d05b5) Thanks [@irshadahmad21](https://github.com/irshadahmad21)! - Fixed the issue of deactivated instance data being lost when there are no channels added.

## 2.0.11

### Patch Changes

- [#72](https://github.com/wpsocio/wp-premium-projects/pull/72) [`2d715da`](https://github.com/wpsocio/wp-premium-projects/commit/2d715dae652c367a7db9069769e372be8184bd13) Thanks [@irshadahmad21](https://github.com/irshadahmad21)! - Fixed validation errors on settings pages

## 2.0.10

### Patch Changes

- [#70](https://github.com/wpsocio/wp-premium-projects/pull/70) [`602cb1c`](https://github.com/wpsocio/wp-premium-projects/commit/602cb1c49d4ce5e2732face56b52cfdde7605067) Thanks [@irshadahmad21](https://github.com/irshadahmad21)! - Fixed plugin menu being hidden during upgrade

## 2.0.9

### Patch Changes

- [#67](https://github.com/wpsocio/wp-premium-projects/pull/67) [`555c3a8`](https://github.com/wpsocio/wp-premium-projects/commit/555c3a8025ad1a8e5bb3513761db3f084b0eb026) Thanks [@irshadahmad21](https://github.com/irshadahmad21)! - Fixed PHP 7.4 critical error on settings page

## 2.0.8

### Patch Changes

- [#65](https://github.com/wpsocio/wp-premium-projects/pull/65) [`a70ecbf`](https://github.com/wpsocio/wp-premium-projects/commit/a70ecbf73c5342eb416f5ac67ca9b0d962d17a5d) Thanks [@irshadahmad21](https://github.com/irshadahmad21)! - Enabled support for PHP 7.4 after user feedback

## 2.0.7

### Patch Changes

- [#60](https://github.com/wpsocio/wp-premium-projects/pull/60) [`6b344b6`](https://github.com/wpsocio/wp-premium-projects/commit/6b344b622bcf4a479b6ae4270d04e456710663fe) Thanks [@irshadahmad21](https://github.com/irshadahmad21)! - Added "Select all" option for channels in block editor

- [#62](https://github.com/wpsocio/wp-premium-projects/pull/62) [`5eba913`](https://github.com/wpsocio/wp-premium-projects/commit/5eba9136f00126ccc14b229cb4e3c4de7793eab7) Thanks [@irshadahmad21](https://github.com/irshadahmad21)! - Updated minimum required PHP version to 8.0

## 2.0.6

### Bug fixes

- Fixed the emojis in notifications not being sent.

### Enhancements

- Added support for posting to topics in Instant Messages

## [2.0.5 - 2023-11-22](https://github.com/wpsocio/wptelegram-pro/releases/tag/v2.0.5)

### Enhancements

- Added support for custom emojis `<tg-emoji emoji-id="5368324170671202286">👍</tg-emoji>`
- Added support for `<blockquote>` tag

### Bug fixes

- Fixed "is empty" and "is not empty" rules not working

## [2.0.4 - 2023-10-25](https://github.com/wpsocio/wptelegram-pro/releases/tag/v2.0.4)

### Enhancements

- Added support for Telegram Login and Mini App buttons
- Added support for WooCommerce product boolean methods like `{wc:is_on_sale}`, `{wc:is_featured}` etc.

### Bug fixes

- Fixed the bug related to `{post_author}` always returning the username.

## [2.0.3 - 2023-09-17](https://github.com/wpsocio/wptelegram-pro/releases/tag/v2.0.3)

### Bug fixes

- Fixed post excerpt not trimmed when using media group.

## [2.0.2 - 2023-09-17](https://github.com/wpsocio/wptelegram-pro/releases/tag/v2.0.2)

### Bug fixes

- Fixed content images and WC gallery not sent when 10 or more.
- Fixed the failure of sending posts with large size images

## [2.0.1 - 2023-07-7](https://github.com/wpsocio/wptelegram-pro/releases/tag/v2.0.1)

### Enhancements

- Added German translation

## [2.0.0 - 2023-05-22](https://github.com/wpsocio/wptelegram-pro/releases/tag/v2.0.0)

### Enhancements

- Added better support for HTML formatting.
- Added support for nested tags. You can now use `<b>` inside `<i>` and vice versa.
- Intelligently trim `{post_excerpt}` to preserve the other parts of Message Template.

### Breaking changes

- Removed support for Markdown formatting in favour of better HTML formatting

### Bug fixes

- Fixed the image not being sent "After the text" when "Send files by URL" is disabled
- Fixed the issue of messages not being sent when the markup is not valid

## [1.6.5 - 2023-05-20](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.6.5)

### Bug fixes

- Fixed the email attachments not being sent by default.
- Fixed PHP warning in the bot API updates handler.

## [1.6.4 - 2023-04-23](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.6.4)

### Enhancements

- Added built-in support for WooCommerce variable product data

### Bug fixes

- Fixed the complex macros like {encode:{cf:field_name}} getting removed when {cf:field_name} duplicated in the message template
- Fixed logs to avoid bot token added to URL

## [1.6.3 - 2023-03-25](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.6.3)

### Enhancements

- Improved message template sanitization to prevent breaking the markup

### Bug fixes

- Fixed PHP warning related to edited channel post updates
- Fixed Inline Query handler for Bots module

## [1.6.2 - 2023-02-19](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.6.2)

### Bug fixes

- Fixed PHP Fatal error caused by last update

## [1.6.1 - 2023-02-18](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.6.1)

### Enhancements

- Added support for adding internal note to chat IDs

## [1.6.0 - 2023-01-31](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.6.0)

### Enhancements

- Added the new experimental HTML converter for better formatting of email notifications
- The new can be enabled using `add_filter( 'wptelegram_pro_notify_use_experimental_text', '__return_true' );`

### Bug fixes

- Fixed escaping of special characters for instant posts

## [1.5.16 - 2023-01-5](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.16)

### Bug fixes

- Fixed PHP warning when not using message thread ID

## [1.5.15 - 2022-12-8](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.15)

### Improvements

- Improved the default value for Send to Telegram option on post edit page

### Enhancements

- Added support for sending messages to topics with groups

### Bug fixes

- Fixed messages not sent when replied-to message is not found

## [1.5.14 - 2022-11-19](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.14)

### Bug fixes

- Fixed PHP warnings in logger

## [1.5.13 - 2022-11-1](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.13)

### Bug fixes

- Fixed warnings in PHP 8.x

## [1.5.12 - 2022-10-31](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.12)

### Improvements

- Improved logging for better understanding of errors

### Bug fixes

- Fixed PHP warning related to edited message updates

## [1.5.11 - 2022-09-10](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.11)

### Enhancements

- Added custom filter for WooCommerce gallery media group
- Added support for sorting of Post to Telegram instances

## [1.5.10 - 2022-07-22](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.10)

### Enhancements

- Post to Telegram: Added support for dynamic template for URL button labels.

### Bug fixes

- Fixed deprecation warnings for PHP 8.1

## [1.5.9 - 2022-06-12](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.9)

### Enhancements

- Added support for <tg-spoiler> tag
- Added and improved filters for HTML and Markdown support
- Improved logging options to prevent users from mistakes

## [1.5.8 - 2022-03-26](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.8)

### Bug fixes

- Fixed Post to Telegram rule search bug

## [1.5.7 - 2022-02-2](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.7)

### Bug fixes

- Fixed Instant Messages not sent

## [1.5.6 - 2022-01-5](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.6)

### Bug fixes

- Fixed broken upgrades for Post to Telegram buttons
- Fixed fatal error caused on some web hosts

## [1.5.5 - 2021-12-31](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.5)

### Enhancements

- Added "Protect content" option to Post to Telegram.

## [1.5.4 - 2021-12-11](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.4)

### Bug fixes

- Fixed inline buttons not loading
- Fixed featured image not shown after the text when Send files by URL is OFF

## [1.5.3 - 2021-11-26](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.3)

### Bug fixes

- Fixed PHP warnings

## [1.5.2 - 2021-11-7](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.2)

### Enhancements

- Inline keyboard buttons are now editable.

### Bug fixes

- Fixed Additional Media and WC Gallery not sent when Send files by URL is disabled

## [1.5.1 - 2021-10-23](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.1)

### Enhancements

- Added override option for P2TG Send Featured Image.

## [1.5.0 - 2021-10-17](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.5.0)

### Enhancements

- Added support for sending images from post content 🎉
- Added caption support for WooCommerce product gallery images 🎉

### Bug fixes

- Fixed instant posts not sent when Post edit switch if OFF
- Fixed posts not sent when Formatting is None

## [1.4.10 - 2021-08-1](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.4.10)

### Bug fixes

- Fixed the issue of data not shown on Post to Telegram instance edit page

## [1.4.9 - 2021-07-24](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.4.9)

### Enhancements

- Added WooCommerce product gallery support 🎉

## [1.4.8 - 2021-07-5](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.4.8)

### Bug fixes

- Fixed admin page not shown just after upgrade
- Fixed multiple empty lines in post content and excerpt

## [1.4.7 - 2021-06-14](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.4.7)

### Bug fixes

- Fixed licence check requests

### Enhancements

- Added `{post_slug}` macro

## [1.4.6 - 2021-06-10](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.4.6)

### Bug fixes

- Fixed licence activation when migrating servers
- Fixed parent category rule bug in Post to Telegram
- Fixed proxy import from free version

## [1.4.5 - 2021-05-7](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.4.5)

### Bug fixes

- Fixed the issue of posts not sent when using multiple instances
- Fixed WooCommerce REST API products not sent to Telegram
- Fixed the delay in override settings preventing publish post

## [1.4.4 - 2021-05-4](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.4.4)

### Bug fixes

- Fixed the Share button URL encoding

## [1.4.3 - 2021-05-3](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.4.3)

### Bug fixes

- Fixed upgrade bug in additional media and inline keyboard when empty
- Fixed upgrade bug in Post to Telegram rules when empty
- Fixed the issue of settings not saved due to trailing slash redirects

## [1.4.2 - 2021-05-2](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.4.2)

### Bug fixes

- Fixed the error with `{tags}` and `{categories}`

## [1.4.1 - 2021-05-2](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.4.1)

### Bug fixes

- Fixed crashing of instance editor

## [1.4.0 - 2021-05-2](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.4.0)

### Enhancements

- Switched to PHP namespaces
- Added support for custom rules for Post to Telegram 🎉
- Added support for Audio and Document in Additional Media groups
- Added instance settings to Instant Post options on post list page
- Better support for block editor override settings
- Improved logging for better diagnosis
- UI Improvements

### Bug fixes

- Fixed wrongly encoded caption when duplicating instances
- Fixed import settings from the free version
- Fixed override settings for classic editor
- Fixed the YouTube links being stripped out from the content.

## [1.3.0 - 2021-01-31](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.3.0)

### Enhancements

- Added Instant Messages module 🎉
- Added support for using macros in template logic comparison values
- Enhanced Post to Telegram template logic by adding `STARTS_WITH` and `ENDS_WITH` operators
- Improved the logic for deciding new and existing posts

### Bug fixes

- Fixed the bug - bot token not being updated for modules when changed

## [1.2.1 - 2020-10-5](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.2.1)

### Bug fixes

- Fixed the issue of P2TG instance active status not being saved.

## [1.2.0 - 2020-10-3](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.2.0)

### Enhancements

- Added Additional Media support for Post to Telegram

### Bug fixes

- Fixed the issue of empty template not being saved

## [1.1.3 - 2020-09-2](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.1.3)

### Bug fixes

- Removed space at the beginning when using Single Message

## [1.1.2 - 2020-08-29](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.1.2)

### Bug fixes

- Fixed escaping of Markdown when nested
- Fixed categories as hashtags
- Fixed hastags at the beginning when using Single Message

## [1.1.1 - 2020-08-26](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.1.1)

### Bug fixes

- Fixed escaping of Markdown special characters in post data

## [1.1.0 - 2020-08-25](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.1.0)

### Enhancements

- Added advanced template logic.
- Added support for MarkdownV2.

### Bug fixes

- Fixed validation for instances after import

## [1.0.5 - 2020-08-20](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.0.5)

### Enhancements

- Added one click import settings from free version
- Added filter to disable long polling

### Bug fixes

- Fixed manifest file not found issue
- Fixed block editor assets

## [1.0.4 - 2020-08-15](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.0.4)

### Bug fixes

- Fixed syntax error for PHP 5.6
- Fixed wrong post data when importing in bulk
- Fixed admin menu icon
- Fix plugin update issue

## [1.0.3 - 2020-08-7](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.0.3)

### Bug fixes

- Delayed loading of modules to fix conflict with other plugins
- Fixed Send to Telegram override for scheduled posts
- Fixed saving of empty values for "Use when"
- Fixed webhook issue when same bot is used for Telegram widget

## [1.0.2 - 2020-08-3](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.0.2)

### Enhancements

- Added intro video

### Bug fixes

- Fixed instances meta conflict
- Fixed Admin menu icon fonts
- Fixed the instance not loading issue when the bot is deleted
- Fixed instance rules for multiple delays
- Fixed p2tg template escape characters

## [1.0.1 - 2020-08-1](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.0.1)

### Bug fixes

- Disables message update processing by default
- Fixed messed up message templare and keyboard for duplicate instances
- Fixed the bug in messed up instance delay
- Fixed inline buttons for delayed instances

## [1.0.0 - 2020-08-1](https://github.com/wpsocio/wptelegram-pro/releases/tag/v1.0.0)

- Initial Release.
